package ktc.secure.coding.utils;


import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CommonWebUtil {

    // SQL Injection을 탐지하기 위한 문자열 패턴 모음집. 
    // SQL Injection 공격에서 자주 사용되는 구문들이 포함되어 있음.
    private static final Set<String> SQL_INJECTION_PATTERNS = Set.of(
        "or '1'='1", "--", ";--", ";", "/\\*", "\\*/", "@@", "char", "nchar", "varchar", "nvarchar", 
        "alter", "begin", "cast", "create", "cursor", "declare", "delete", "drop", "end", 
        "exec", "execute", "fetch", "insert", "kill", "select", "sys", "sysobjects", 
        "syscolumns", "table", "update", "sleep", "benchmark", "pg_sleep", "utl_http", 
        "dbms_pipe", "waitfor", "delay", "rlike", "concat", "mid", "version", "if", "now", 
        "sysdate", "xor",
        // 추가된 패턴: 특수한 SQL Injection 공격을 감지하기 위한 추가 패턴
        "or sleep\\(\\d+\\)='", "xor\\(if\\(now\\(\\)=sysdate\\(\\),sleep\\(\\d+\\),0\\)\\)xor",
        "xor\\(if\\(now\\(\\)=sysdate\\(\\),sleep\\(\\d+\\),0\\)\\)xor'"
    );

    // 특수문자 탐지를 위한 정규 표현식 패턴.
    // 주로 SQL Injection 공격에 사용될 수 있는 특수문자들('",;-\s#)을 탐지함.
    private static final Pattern SPECIAL_CHAR_PATTERN = Pattern.compile("(['\";\\-\\s#])", Pattern.CASE_INSENSITIVE);

    // SQL Injection 패턴을 감지하기 위한 정규 표현식 패턴.
    // 위에서 정의한 SQL_INJECTION_PATTERNS를 기반으로 SQL Injection 공격 시도 여부를 탐지함.
    private static final Pattern SQL_INJECTION_PATTERN = Pattern.compile(
        "(?i)(" + String.join("|", SQL_INJECTION_PATTERNS) + ")", // 패턴을 하나의 정규식으로 합침.
        Pattern.CASE_INSENSITIVE // 대소문자를 구분하지 않음.
    );

    // 입력된 문자열에서 SQL Injection 공격을 탐지하는 메소드.
    public static String detectSQLInjectionRisk(String input) {
        // 입력값이 null이거나 비어있으면 그대로 반환.
        if (input == null || input.isEmpty()) {
            return input;
        }

        // 입력된 문자열에서 특수문자와 SQL Injection 패턴을 각각 매칭시킴.
        Matcher specialCharMatcher = SPECIAL_CHAR_PATTERN.matcher(input);
        Matcher sqlInjectionMatcher = SQL_INJECTION_PATTERN.matcher(input);

        // SQL Injection 패턴이 발견되면 해당 문자열을 경고 메시지로 변환하여 반환.
        if (sqlInjectionMatcher.find()) {
            return "SQL Injection Detected: " + input;
        }
        // SQL Injection이 발견되지 않으면 원본 문자열을 반환.
        return input;
    }

    // JSON 객체 내에 SQL Injection 위험이 있는 문자열이 포함되어 있는지 검사하고, 필요한 경우 수정하는 메소드.
    public static void validateJSONObject(JSONObject jsonObject) throws JSONException {
        // JSON 객체의 각 키-값 쌍을 순회하면서 값을 검사.
        for (String key : jsonObject.keySet()) {
            Object value = jsonObject.get(key);
            // 값이 또 다른 JSON 객체인 경우 재귀적으로 검사.
            if (value instanceof JSONObject) {
                validateJSONObject((JSONObject) value);
            } 
            // 값이 JSON 배열인 경우 각 요소를 검사.
            else if (value instanceof JSONArray) {
                validateJSONArray((JSONArray) value);
            } 
            // 값이 문자열인 경우 SQL Injection 위험이 있는지 검사하고 수정.
            else if (value instanceof String) {
                String validatedValue = detectSQLInjectionRisk((String) value);
                // 수정이 필요한 경우 JSON 객체의 값을 갱신.
                if (!validatedValue.equals(value)) {
                    jsonObject.put(key, validatedValue);
                }
            }
        }
    }

    // JSON 배열 내에 SQL Injection 위험이 있는 문자열이 포함되어 있는지 검사하고, 필요한 경우 수정하는 메소드.
    public static void validateJSONArray(JSONArray jsonArray) throws JSONException {
        // 배열의 각 요소를 순회하면서 값을 검사.
        for (int i = 0; i < jsonArray.length(); i++) {
            Object value = jsonArray.get(i);
            // 요소가 JSON 객체인 경우 재귀적으로 검사.
            if (value instanceof JSONObject) {
                validateJSONObject((JSONObject) value);
            } 
            // 요소가 또 다른 JSON 배열인 경우 재귀적으로 검사.
            else if (value instanceof JSONArray) {
                validateJSONArray((JSONArray) value);
            } 
            // 요소가 문자열인 경우 SQL Injection 위험이 있는지 검사하고 수정.
            else if (value instanceof String) {
                String validatedValue = detectSQLInjectionRisk((String) value);
                // 수정이 필요한 경우 배열의 값을 갱신.
                if (!validatedValue.equals(value)) {
                    jsonArray.put(i, validatedValue);
                }
            }
        }
    }

    // 입력된 문자열, JSON 데이터, 헤더 정보를 종합적으로 검사하여 결과를 반환하는 메소드.
    public static String validateAll(String input, String jsonData, Map<String, String> headers) {
        StringBuilder result = new StringBuilder();

        // 입력된 일반 문자열(input)을 검사하고 결과를 기록.
        if (input != null) {
            result.append("Input: ").append(detectSQLInjectionRisk(input)).append("\n");
        }

        // JSON 데이터(jsonData)를 검사하고, 유효하지 않은 JSON 포맷일 경우 예외 처리.
        if (jsonData != null) {
            try {
                JSONObject jsonObject = new JSONObject(jsonData);
                validateJSONObject(jsonObject); // JSON 객체 내의 SQL Injection 위험 검사.
                result.append("JSON: ").append(jsonObject.toString()).append("\n");
            } catch (JSONException e) {
                result.append("JSON: Invalid JSON format\n");
            }
        }

        // HTTP 헤더 정보를 검사하고, 각 헤더 값을 검증하여 결과를 기록.
        if (headers != null) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                String validatedValue = detectSQLInjectionRisk(value);
                result.append("Header ").append(key).append(": ").append(validatedValue).append("\n");
            }
        }

        // 종합 결과를 문자열로 반환.
        return result.toString();
    }
}
