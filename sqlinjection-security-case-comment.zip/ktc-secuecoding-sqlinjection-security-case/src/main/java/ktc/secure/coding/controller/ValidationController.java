package ktc.secure.coding.controller;

import ktc.secure.coding.utils.CommonWebUtil;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class ValidationController {

    @PostMapping("/validate")
    public String validate(
            @RequestParam(name = "input", required = false) String input,
            @RequestBody(required = false) String jsonData,
            @RequestHeader Map<String, String> headers) {
        return CommonWebUtil.validateAll(input, jsonData, headers);
    }
}
