
  package ktc.secure.coding;
  

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;

import ktc.secure.coding.utils.CommonWebUtil;



public class CommonWebUtilTest {

    @Test
    public void testDetectSQLInjectionRisk() {
        String maliciousInput = "' OR '1'='1";
        String expected = "SQL Injection Detected: ' OR '1'='1";
        assertEquals(expected, CommonWebUtil.detectSQLInjectionRisk(maliciousInput));

        String safeInput = "safeInput";
        assertEquals(safeInput, CommonWebUtil.detectSQLInjectionRisk(safeInput));
    }

    @Test
    public void testValidateJSONObject() {
        try {
            // SQL Injection 의심 JSON 객체
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("email", "test@test.com' OR '1'='1");
            CommonWebUtil.validateJSONObject(jsonObject);
            assertEquals("SQL Injection Detected: test@test.com' OR '1'='1", jsonObject.getString("email"));

            // 정상적인 JSON 객체
            jsonObject.put("email", "test@test.com");
            CommonWebUtil.validateJSONObject(jsonObject);
            assertEquals("test@test.com", jsonObject.getString("email"));
        } catch (Exception e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    public void testValidateJSONArray() {
        try {
            // SQL Injection 의심 JSON 배열
            JSONArray jsonArray = new JSONArray();
            jsonArray.put("test@test.com' OR '1'='1");
            CommonWebUtil.validateJSONArray(jsonArray);
            assertEquals("SQL Injection Detected: test@test.com' OR '1'='1", jsonArray.getString(0));

            // 정상적인 JSON 배열
            jsonArray = new JSONArray();
            jsonArray.put("test@test.com");
            CommonWebUtil.validateJSONArray(jsonArray);
            assertEquals("test@test.com", jsonArray.getString(0));
        } catch (Exception e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    public void testValidateAll() {
        // 정상적인 입력값과 헤더
        String input = "safe input";
        String jsonData = "{\"key1\": \"value1\"}";
        Map<String, String> headers = new HashMap<>();
        headers.put("Header1", "safe header");

        String result = CommonWebUtil.validateAll(input, jsonData, headers);
        System.out.println("정상 입력 결과: \n" + result); // 디버깅을 위한 출력
        assertTrue(result.contains("Input: safe input"), "정상 입력값 검사 실패: " + result);
        assertTrue(result.contains("JSON: {\"key1\":\"value1\"}"), "정상 JSON 검사 실패: " + result);
        assertTrue(result.contains("Header Header1: safe header"), "정상 헤더 검사 실패: " + result);

        // SQL Injection 의심 입력값과 헤더
        input = "' OR '1'='1";
        jsonData = "{\"key2\": \"' OR '1'='1\"}";
        headers.put("Header2", "' OR '1'='1");

        result = CommonWebUtil.validateAll(input, jsonData, headers);
        System.out.println("SQL Injection 의심 입력 결과: \n" + result); // 디버깅을 위한 출력

        // 예상 결과 문자열 정의
        String expectedResult = "Input: SQL Injection Detected: ' OR '1'='1\n" +
                                "JSON: {\"key2\":\"SQL Injection Detected: ' OR '1'='1\"}\n" +
                                "Header Header1: safe header\n" +
                                "Header Header2: SQL Injection Detected: ' OR '1'='1\n";

        // 개별 비교를 통한 디버깅
        boolean inputCheck = result.contains("Input: SQL Injection Detected: ' OR '1'='1");
        boolean jsonCheck = result.contains("JSON: {\"key2\":\"SQL Injection Detected: ' OR '1'='1\"}");
        boolean header1Check = result.contains("Header Header1: safe header");
        boolean header2Check = result.contains("Header Header2: SQL Injection Detected: ' OR '1'='1");

        System.out.println("inputCheck: " + inputCheck);
        System.out.println("jsonCheck: " + jsonCheck);
        System.out.println("header1Check: " + header1Check);
        System.out.println("header2Check: " + header2Check);

        // 개별 결과 비교
        assertTrue(inputCheck, "Input 검사 실패: " + result);
        assertTrue(jsonCheck, "JSON 검사 실패: " + result);
        assertTrue(header1Check, "Header1 검사 실패: " + result);
        assertTrue(header2Check, "Header2 검사 실패: " + result);

        // 전체 결과 비교
        System.out.println("Expected result: " + expectedResult);
        System.out.println("Actual result: " + result);
        assertEquals(expectedResult.trim(), result.trim(), "전체 결과 비교 실패");
    }

    @Test
    public void testInvalidJSON() {
        String invalidJson = "{\"email\": test@test.com\"}";
        String result = CommonWebUtil.validateAll(null, invalidJson, null);
        System.out.println("유효하지 않은 JSON 결과: \n" + result); // 디버깅을 위한 출력
        assertTrue(result.contains("JSON: Invalid JSON format"));
    }
}
