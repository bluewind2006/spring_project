package ktc.secure.coding.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LdapSecurityUtilTest {

    @Test
    public void testIsValidInput() {
        System.out.println("Testing validInput123: " + LdapSecurityUtil.isValidInput("validInput123"));
        assertTrue(LdapSecurityUtil.isValidInput("validInput123"), "validInput123 should be valid");

        System.out.println("Testing invalid*Input: " + LdapSecurityUtil.isValidInput("invalid*Input"));
        assertFalse(LdapSecurityUtil.isValidInput("invalid*Input"), "invalid*Input should be invalid");

        System.out.println("Testing invalid(Input: " + LdapSecurityUtil.isValidInput("invalid(Input"));
        assertFalse(LdapSecurityUtil.isValidInput("invalid(Input"), "invalid(Input should be invalid");

        System.out.println("Testing invalid)Input: " + LdapSecurityUtil.isValidInput("invalid)Input"));
        assertFalse(LdapSecurityUtil.isValidInput("invalid)Input"), "invalid)Input should be invalid");

        System.out.println("Testing invalid\\Input: " + LdapSecurityUtil.isValidInput("invalid\\Input"));
        assertFalse(LdapSecurityUtil.isValidInput("invalid\\Input"), "invalid\\Input should be invalid");

        System.out.println("Testing invalid/Input: " + LdapSecurityUtil.isValidInput("invalid/Input"));
        assertFalse(LdapSecurityUtil.isValidInput("invalid/Input"), "invalid/Input should be invalid");

        System.out.println("Testing invalid\\0Input: " + LdapSecurityUtil.isValidInput("invalid\0Input"));
        assertFalse(LdapSecurityUtil.isValidInput("invalid\0Input"), "invalid\\0Input should be invalid");

        System.out.println("Testing null: " + LdapSecurityUtil.isValidInput(null));
        assertFalse(LdapSecurityUtil.isValidInput(null), "null should be invalid");

        System.out.println("Testing empty string: " + LdapSecurityUtil.isValidInput(""));
        assertFalse(LdapSecurityUtil.isValidInput(""), "Empty string should be invalid");
    }

    @Test
    public void testEscapeLDAPSearchFilter() {
        assertEquals("validInput123", LdapSecurityUtil.escapeLDAPSearchFilter("validInput123"));
        assertEquals("\\2ainvalid\\2a", LdapSecurityUtil.escapeLDAPSearchFilter("*invalid*"));
        assertEquals("\\28invalid\\29", LdapSecurityUtil.escapeLDAPSearchFilter("(invalid)"));
        assertEquals("\\5cinvalid\\5c", LdapSecurityUtil.escapeLDAPSearchFilter("\\invalid\\"));
        assertEquals("invalid\\00", LdapSecurityUtil.escapeLDAPSearchFilter("invalid\0"));
    }

    @Test
    public void testDetectLDAPInjectionRisk() {
        assertEquals("validInput123", LdapSecurityUtil.detectLDAPInjectionRisk("validInput123"));
        assertEquals("LDAP Injection Detected: *invalid*", LdapSecurityUtil.detectLDAPInjectionRisk("*invalid*"));
        assertEquals("LDAP Injection Detected: (invalid)", LdapSecurityUtil.detectLDAPInjectionRisk("(invalid)"));
        assertEquals("LDAP Injection Detected: \\invalid\\", LdapSecurityUtil.detectLDAPInjectionRisk("\\invalid\\"));
        assertEquals("LDAP Injection Detected: invalid\0", LdapSecurityUtil.detectLDAPInjectionRisk("invalid\0"));
    }
}