package ktc.secure.coding.util;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LdapSecurityUtil {

    // LDAP 필터에서 사용되는 특수 문자를 감지하기 위한 정규식 패턴.
    // 이 패턴은 특수 문자 *, (), \, / 및 널 문자를 포함함.
    private static final Pattern SPECIAL_CHAR_PATTERN = Pattern.compile("[*()\\\\/\\x00]");

    // 입력 문자열이 유효한지 확인하는 메서드.
    // 입력이 null이 아니고, 빈 문자열이 아니며, 영문자와 숫자만 포함하는 경우 true를 반환함.
    public static boolean isValidInput(String input) {
        return input != null && !input.isEmpty() && input.matches("^[a-zA-Z0-9]*$");
    }

    // LDAP 검색 필터에 안전하게 사용하기 위해 특수 문자를 이스케이프 처리하는 메서드.
    // 특정 특수 문자를 LDAP 필터에서 안전하게 사용할 수 있도록 이스케이프 시퀀스로 대체함.
    public static String escapeLDAPSearchFilter(String filter) {
        StringBuilder sb = new StringBuilder(); // 결과를 저장할 StringBuilder를 초기화.
        for (int i = 0; i < filter.length(); i++) { // 입력 문자열의 각 문자에 대해 반복.
            char curChar = filter.charAt(i); // 현재 문자를 가져옴.
            sb.append(switch (curChar) { // 특수 문자에 대해 이스케이프 처리.
                case '\\' -> "\\5c";  // 백슬래시(\)는 \5c로 이스케이프.
                case '*' -> "\\2a";   // 별표(*)는 \2a로 이스케이프.
                case '(' -> "\\28";   // 왼쪽 괄호(()는 \28로 이스케이프.
                case ')' -> "\\29";   // 오른쪽 괄호())는 \29로 이스케이프.
                case '\0' -> "\\00";  // 널 문자(\0)는 \00로 이스케이프.
                case '+' -> "\\2b";   // 더하기 기호(+)는 \2b로 이스케이프.
                case ',' -> "\\2c";   // 콤마(,)는 \2c로 이스케이프.
                case ';' -> "\\3b";   // 세미콜론(;)은 \3b로 이스케이프.
                case '<' -> "\\3c";   // 왼쪽 꺾쇠(<)는 \3c로 이스케이프.
                case '>' -> "\\3e";   // 오른쪽 꺾쇠(>)는 \3e로 이스케이프.
                case '=' -> "\\3d";   // 등호(=)는 \3d로 이스케이프.
                default -> curChar;   // 특수 문자가 아닌 경우 원래 문자를 그대로 추가.
            });
        }
        return sb.toString(); // 이스케이프 처리된 문자열을 반환.
    }

    // LDAP 인젝션 위험을 감지하는 메서드.
    // 입력 문자열이 특수 문자를 포함하는지 확인하고, 포함된 경우 경고 메시지를 반환함.
    public static String detectLDAPInjectionRisk(String input) {
        if (input == null || input.isEmpty()) { // 입력이 null이거나 빈 문자열일 경우 그대로 반환.
            return input;
        }

        Matcher specialCharMatcher = SPECIAL_CHAR_PATTERN.matcher(input); // 입력 문자열에서 특수 문자를 찾기 위한 Matcher 생성.
        if (specialCharMatcher.find()) { // 특수 문자가 발견되면 LDAP 인젝션 경고 메시지를 반환.
            return "LDAP Injection Detected: " + input;
        }
        return input; // 특수 문자가 없으면 입력 문자열을 그대로 반환.
    }
}
