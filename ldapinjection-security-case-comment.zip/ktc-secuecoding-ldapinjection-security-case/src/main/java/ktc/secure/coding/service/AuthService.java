package ktc.secure.coding.service;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.directory.DirContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.AuthenticationException;
import org.springframework.ldap.NamingException;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.support.LdapUtils;
import org.springframework.security.ldap.authentication.LdapAuthenticator;
import org.springframework.stereotype.Service;

import ktc.secure.coding.util.LdapSecurityUtil;

@Service
public class AuthService {

    // 로깅을 위한 Logger 인스턴스를 생성.
    private static final Logger LOGGER = Logger.getLogger(AuthService.class.getName());

    // Spring의 @Autowired를 사용하여 LdapTemplate과 LdapAuthenticator를 주입받음.
    @Autowired
    private LdapTemplate ldapTemplate;

    @Autowired
    private LdapAuthenticator authenticator;

    // 사용자의 인증을 처리하는 메서드.
    public boolean authenticateUser(String username, String password) {
        // LDAP 인젝션 방지를 위해 사용자 이름과 비밀번호를 이스케이프 처리.
        username = LdapSecurityUtil.escapeLDAPSearchFilter(username);
        password = LdapSecurityUtil.escapeLDAPSearchFilter(password);

        // 사용자 이름과 비밀번호가 유효한 입력인지 확인. 유효하지 않으면 false를 반환.
        if (!LdapSecurityUtil.isValidInput(username) || !LdapSecurityUtil.isValidInput(password)) {
            LOGGER.log(Level.WARNING, "Invalid input detected for username: {0}", username);
            return false;
        }

        DirContext ctx = null; // LDAP 컨텍스트를 관리할 객체를 초기화.
        try {
            // LDAP 서버에 사용자 인증을 시도. 인증에 성공하면 컨텍스트 객체가 반환됨.
            ctx = ldapTemplate.getContextSource().getContext(
                "uid=" + username + ",ou=users,dc=example,dc=com", password);
            
            // 컨텍스트 객체가 null이 아니면 인증 성공으로 간주하고 true를 반환.
            return ctx != null;
        } catch (AuthenticationException e) {
            // 인증에 실패한 경우 경고 메시지를 로깅.
            LOGGER.log(Level.WARNING, "Authentication failed for username: {0}", username);
        } catch (NamingException e) {
            // LDAP 이름 지정 오류가 발생한 경우 심각한 예외로 로깅.
            LOGGER.log(Level.SEVERE, "LDAP naming exception occurred for username: {0}", username);
        } catch (Exception e) {
            // 기타 예기치 못한 예외가 발생한 경우 심각한 예외로 로깅.
            LOGGER.log(Level.SEVERE, "Unexpected exception occurred for username: {0}", username);
        } finally {
            // LDAP 컨텍스트를 닫아 자원을 해제.
            LdapUtils.closeContext(ctx);
        }
        // 인증에 실패한 경우 false를 반환.
        return false;
    }
}
