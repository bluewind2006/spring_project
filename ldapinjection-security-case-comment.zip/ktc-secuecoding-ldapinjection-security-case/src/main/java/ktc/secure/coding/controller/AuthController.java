package ktc.secure.coding.controller;

import ktc.secure.coding.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        boolean isAuthenticated = authService.authenticateUser(username, password);
        return isAuthenticated ? "Authentication successful" : "Authentication failed";
    }
}