package ktc.secure.coding.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;

import org.junit.jupiter.api.Test;

public class SecurityUtilTests {

    @Test
    public void testGetSecureFile() {
        String baseDir = "/safe/base/directory";
        String userInputPath = "valid/path.txt";
        try {
            File secureFile = SecurityUtil.getSecureFile(baseDir, userInputPath);
            assertNotNull(secureFile);
            assertTrue(secureFile.getPath().startsWith(new File(baseDir).getCanonicalPath()));
        } catch (IOException e) {
            fail("IOException should not have been thrown");
        }
    }

    @Test
    public void testGetPreparedStatement() {
        String url = "jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE";
        try (Connection connection = DriverManager.getConnection(url, "sa", "")) {
            // 테이블 생성
            String query = "CREATE TABLE IF NOT EXISTS users (id INT PRIMARY KEY, username VARCHAR(255))";
            connection.createStatement().execute(query);

            // 데이터 삽입
            query = "INSERT INTO users (id, username) VALUES (1, 'admin')";
            connection.createStatement().execute(query);

            // PreparedStatement 테스트
            query = "SELECT * FROM users WHERE username = ?";
            String userInput = "admin";
            PreparedStatement preparedStatement = SecurityUtil.getPreparedStatement(connection, query, userInput);
            assertNotNull(preparedStatement);
            assertTrue(preparedStatement.execute());
        } catch (SQLException e) {
            fail("SQLException should not have been thrown: " + e.getMessage());
        }
    }

    @Test
    public void testExecCommand() {
        try {
            // Windows 환경에서 cmd를 통해 echo 명령어 실행
            Process process = SecurityUtil.execCommand("cmd", "/c", "echo Hello, World!");
            assertNotNull(process);
            int exitCode = process.waitFor();
            assertEquals(0, exitCode);
        } catch (IOException | InterruptedException e) {
            fail("IOException or InterruptedException should not have been thrown: " + e.getMessage());
        }
    }

    @Test
    public void testGetCipher() {
        try {
            SecretKey key = SecurityUtil.generateSecretKey();
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            byte[] iv = SecurityUtil.generateIV(cipher);
            Cipher encryptCipher = SecurityUtil.getCipher(Cipher.ENCRYPT_MODE, key, iv);
            assertNotNull(encryptCipher);
        } catch (Exception e) {
            fail("Exception should not have been thrown: " + e.getMessage());
        }
    }

    @Test
    public void testGetSecureConnection() {
        try {
            HttpURLConnection connection = SecurityUtil.getSecureConnection("https://www.example.com");
            assertNotNull(connection);
        } catch (IOException e) {
            fail("IOException should not have been thrown: " + e.getMessage());
        }
    }
}
