package ktc.secure.coding.util;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import java.net.URL;
import java.security.SecureRandom;

//SecurityUtil 클래스는 보안과 관련된 유틸리티 메서드들을 제공하는 클래스입니다.
public class SecurityUtil {

 // 최대 길이 제한 상수. 주로 SQL 쿼리나 명령어, 파일 경로 등의 유효성 검사에 사용됩니다.
 private static final int MAX_LENGTH = 1000;
 
 // 안전한 파일 경로인지 확인하기 위한 정규 표현식. 경로에는 알파벳 대소문자, 숫자, 언더스코어(_), 슬래시(/), 점(.)만 허용됩니다.
 private static final Pattern SAFE_PATH_PATTERN = Pattern.compile("^[a-zA-Z0-9_/.-]+$");

 // 파일 경로 조작 방지 메서드
 // 사용자가 입력한 경로를 기반으로 안전한 File 객체를 반환합니다.
 public static File getSecureFile(String baseDir, String userInputPath) throws IOException {
     // 사용자가 입력한 경로가 안전한지 확인 (정규 표현식과 일치하는지 확인)
     if (!SAFE_PATH_PATTERN.matcher(userInputPath).matches()) {
         throw new SecurityException("Invalid file path detected");
     }

     // baseDir의 정규화된 절대 경로를 가져옵니다.
     File baseDirectory = new File(baseDir).getCanonicalFile();
     // baseDir을 기준으로 사용자가 입력한 경로를 합친 정규화된 절대 경로를 가져옵니다.
     File userFile = new File(baseDirectory, userInputPath).getCanonicalFile();

     // 사용자가 입력한 경로가 baseDir을 벗어나는지 확인합니다. 경로 탐색 공격(Path Traversal)을 방지하기 위함입니다.
     if (!userFile.getPath().startsWith(baseDirectory.getPath())) {
         throw new SecurityException("Potential Path Traversal attack detected");
     }

     // 검증이 끝난 안전한 File 객체를 반환합니다.
     return userFile;
 }

 // SQL 인젝션 방지 메서드
 // SQL 쿼리를 안전하게 실행하기 위해 PreparedStatement를 생성합니다.
 public static PreparedStatement getPreparedStatement(Connection connection, String query, Object... parameters) throws SQLException {
     // 쿼리가 null이거나 너무 길면 예외를 발생시킵니다.
     if (query == null || query.length() > MAX_LENGTH) {
         throw new IllegalArgumentException("Query is too long or null");
     }

     // PreparedStatement 객체를 생성합니다.
     PreparedStatement preparedStatement = connection.prepareStatement(query);
     
     // 쿼리에 전달할 파라미터들을 설정합니다.
     for (int i = 0; i < parameters.length; i++) {
         // 파라미터가 문자열이고 길이가 너무 길면 예외를 발생시킵니다.
         if (parameters[i] instanceof String && ((String) parameters[i]).length() > MAX_LENGTH) {
             throw new IllegalArgumentException("Parameter is too long");
         }
         // 파라미터를 PreparedStatement에 설정합니다.
         preparedStatement.setObject(i + 1, parameters[i]);
     }
     
     // 생성된 PreparedStatement를 반환합니다.
     return preparedStatement;
 }

 // 명령어 삽입 방지 메서드
 // 명령어 실행 시 안전하게 실행되도록 Process 객체를 생성합니다.
 public static Process execCommand(String... command) throws IOException {
     // 명령어가 null이거나 비어있으면 예외를 발생시킵니다.
     if (command == null || command.length == 0) {
         throw new IllegalArgumentException("Command cannot be null or empty");
     }

     // 각 명령어 인자가 너무 길지 않은지 확인합니다.
     for (String cmd : command) {
         if (cmd.length() > MAX_LENGTH) {
             throw new IllegalArgumentException("Command argument is too long");
         }
     }

     // 안전하게 명령어를 실행하기 위해 ProcessBuilder를 사용하여 Process 객체를 생성하고 실행합니다.
     return new ProcessBuilder(command).start();
 }

 // 안전한 암호화 메서드
 // AES 암호화를 위한 Cipher 객체를 생성하고 초기화합니다.
 public static Cipher getCipher(int mode, SecretKey key, byte[] iv) throws Exception {
     // AES 알고리즘을 CBC 모드와 PKCS5Padding을 사용해 Cipher 객체를 생성합니다.
     Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
     
     // IV(초기화 벡터)를 설정합니다.
     IvParameterSpec ivSpec = new IvParameterSpec(iv);
     
     // Cipher 객체를 지정된 모드(암호화 또는 복호화)로 초기화합니다.
     cipher.init(mode, key, ivSpec);
     
     // 초기화된 Cipher 객체를 반환합니다.
     return cipher;
 }

 // IV(초기화 벡터)를 생성하는 메서드
 public static byte[] generateIV(Cipher cipher) {
     // Cipher 객체의 블록 크기에 맞는 바이트 배열을 생성합니다.
     byte[] iv = new byte[cipher.getBlockSize()];
     
     // 안전한 랜덤값을 생성하기 위해 SecureRandom 객체를 사용합니다.
     SecureRandom random = new SecureRandom();
     
     // 랜덤 값을 iv 배열에 채웁니다.
     random.nextBytes(iv);
     
     // 생성된 IV를 반환합니다.
     return iv;
 }

 // AES 비밀 키를 생성하는 메서드
 public static SecretKey generateSecretKey() throws Exception {
     // AES 알고리즘에 대한 KeyGenerator 객체를 생성합니다.
     KeyGenerator keyGen = KeyGenerator.getInstance("AES");
     
     // 256비트 키를 생성하도록 초기화합니다.
     keyGen.init(256);
     
     // 생성된 비밀 키를 반환합니다.
     return keyGen.generateKey();
 }

 // 안전한 네트워크 연결 메서드
 // HTTPS 연결을 생성하고 보안 설정을 적용한 HttpsURLConnection 객체를 반환합니다.
 public static HttpsURLConnection getSecureConnection(String urlString) throws IOException {
     // URL 문자열이 null이거나 너무 길면 예외를 발생시킵니다.
     if (urlString == null || urlString.length() > MAX_LENGTH) {
         throw new IllegalArgumentException("URL is too long or null");
     }

     // URL 객체를 생성합니다.
     URL url = new URL(urlString);
     
     // HttpsURLConnection 객체를 생성합니다.
     HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
     
     // 기본 SSL 소켓 팩토리를 사용하여 SSL 연결을 설정합니다.
     connection.setSSLSocketFactory((SSLSocketFactory) SSLSocketFactory.getDefault());
     
     // 호스트 이름 검증을 설정합니다. 실제 환경에서는 신뢰할 수 있는 호스트만 검증하도록 설정해야 합니다.
     connection.setHostnameVerifier((hostname, session) -> hostname.equals("trusted.hostname.com"));
     
     // 설정된 HttpsURLConnection 객체를 반환합니다.
     return connection;
 }
}
