package ktc.secure.coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtcSecuecodingWhitelabelErrorcaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtcSecuecodingWhitelabelErrorcaseApplication.class, args);
	}

}
