package ktc.secure.coding.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

@Controller
public class CsrfSecurityController {

    @GetMapping("/home")
    public String home(Model model) {
        return "home";
    }

    @PostMapping("/updateProfile")
    public String updateProfile(@RequestParam("name") String name, Model model) { // @RequestParam에 이름 명시
        model.addAttribute("message", "Profile updated successfully for: " + name);
        return "home";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }
}