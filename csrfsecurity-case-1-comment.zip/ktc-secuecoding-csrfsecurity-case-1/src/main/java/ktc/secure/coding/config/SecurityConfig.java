package ktc.secure.coding.config;

/*
 * import org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.security.config.annotation.web.builders.HttpSecurity;
 * import org.springframework.security.web.SecurityFilterChain;
 * 
 * import static org.springframework.security.config.Customizer.withDefaults;
 * 
 * @Configuration public class SecurityConfig {
 * 
 * @Bean public SecurityFilterChain securityFilterChain(HttpSecurity http)
 * throws Exception { http // .csrf(withDefaults()) // CSRF 보호 활성화 .csrf(csrf ->
 * csrf.disable()) // CSRF 비활성화 .authorizeHttpRequests(authorize -> authorize
 * .requestMatchers("/", "/home", "/login").permitAll()
 * .anyRequest().authenticated() ) .formLogin(form -> form .loginPage("/login")
 * .permitAll() ) .logout(logout -> logout .permitAll() );
 * 
 * return http.build(); } }
 */

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    // Spring Security의 필터 체인을 구성하는 메서드. HTTP 보안 설정을 정의.
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // CSRF 보호 설정: Spring Security 6.x에서는 기본값으로 CSRF 보호가 활성화됨.
            .csrf(Customizer.withDefaults()) // CSRF 보호 활성화. (비활성화하려면 주석 처리된 부분을 사용할 수 있음)
            
            // 요청에 대한 접근 권한을 설정.
            .authorizeHttpRequests(authorize -> authorize
                // 특정 경로에 대한 접근을 모든 사용자에게 허용.
                .requestMatchers("/", "/home", "/login", "/updateProfile", "/csrf-attack.html", "/static/**").permitAll()
                
                // 그 외의 모든 요청은 인증된 사용자만 접근할 수 있도록 설정.
                .anyRequest().authenticated()
            )
            
            // 폼 로그인을 사용하도록 설정.
            .formLogin(form -> form
                // 커스텀 로그인 페이지 경로 설정.
                .loginPage("/login")
                // 로그인 페이지에 대한 접근을 모든 사용자에게 허용.
                .permitAll()
            )
            
            // 로그아웃 설정.
            .logout(logout -> logout
                // 로그아웃에 대한 접근을 모든 사용자에게 허용.
                .permitAll()
            )
            
            // 커스텀 필터를 필터 체인에 추가. AutoLoginFilter를 UsernamePasswordAuthenticationFilter 앞에 추가.
            .addFilterBefore(new AutoLoginFilter(userDetailsService()), UsernamePasswordAuthenticationFilter.class);

        // 위에서 정의된 보안 설정을 적용하여 SecurityFilterChain을 생성하고 반환.
        return http.build();
    }

    // 메모리 내에 사용자 정보를 관리하는 UserDetailsService를 설정하는 메서드.
    @Bean
    public UserDetailsService userDetailsService() {
        // 사용자 "user"를 생성. 패스워드는 {noop} 인코딩을 사용하여 평문으로 저장.
        UserDetails user = User.builder()
            .username("user")
            .password("{noop}password") // NoOpPasswordEncoder를 사용하여 비밀번호를 인코딩하지 않고 평문으로 저장.
            .roles("USER") // 사용자의 역할(Role)을 "USER"로 설정.
            .build();
        
        // InMemoryUserDetailsManager를 사용하여 메모리 내에서 사용자 정보를 관리.
        return new InMemoryUserDetailsManager(user);
    }
}
