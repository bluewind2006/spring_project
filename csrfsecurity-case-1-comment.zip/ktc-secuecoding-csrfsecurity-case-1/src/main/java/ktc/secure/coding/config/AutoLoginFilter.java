package ktc.secure.coding.config;

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

public class AutoLoginFilter extends OncePerRequestFilter {

    // UserDetailsService는 Spring Security에서 사용자 정보를 로드하는 데 사용되는 서비스.
    private final UserDetailsService userDetailsService;

    // 생성자에서 UserDetailsService를 주입받아 초기화.
    public AutoLoginFilter(UserDetailsService userDetailsService) {
        this.userDetailsService = userDetailsService;
    }

    // 요청이 처리될 때 필터가 한 번만 실행되도록 보장하는 메서드.
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        
        // 현재 SecurityContext에서 인증 정보가 없는 경우 자동 로그인을 수행.
        if (SecurityContextHolder.getContext().getAuthentication() == null) {
            // UserDetailsService를 통해 사용자 정보를 로드. 여기서는 "user"라는 사용자 이름을 사용.
            UserDetails userDetails = userDetailsService.loadUserByUsername("user");
            
            // 사용자 정보를 기반으로 UsernamePasswordAuthenticationToken 생성.
            // 비밀번호는 null로 설정하고, 사용자 권한을 설정함.
            UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                    userDetails, null, userDetails.getAuthorities());
            
            // 현재 요청에 대한 추가적인 인증 정보를 설정.
            authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
            
            // SecurityContext에 생성한 인증 정보를 설정하여 사용자 인증을 완료.
            SecurityContextHolder.getContext().setAuthentication(authentication);
        }
        
        // 다음 필터 체인으로 요청과 응답을 전달하여, 추가적인 필터나 요청 처리를 계속 진행.
        chain.doFilter(request, response);
    }
}
