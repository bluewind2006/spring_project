package ktc.secure.coding.util;


import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.security.SecureRandom;
import java.util.Base64;

public class CsrfTokenUtil {

    // 세션에 저장될 CSRF 토큰의 속성 이름을 정의.
    private static final String CSRF_TOKEN_ATTRIBUTE = "csrfToken";
    
    // 암호학적으로 안전한 랜덤 숫자를 생성하기 위해 SecureRandom 인스턴스를 생성.
    private static final SecureRandom secureRandom = new SecureRandom();

    // HTTP 요청으로부터 세션을 가져와 새로운 CSRF 토큰을 생성하고 세션에 저장하는 메서드.
    public static String generateCsrfToken(HttpServletRequest request) {
        // 새로운 랜덤 토큰을 생성.
        String token = generateRandomToken();
        // 요청으로부터 세션을 가져옴. 세션이 없으면 새로 생성.
        HttpSession session = request.getSession();
        // 세션에 CSRF 토큰을 속성 이름(CSRF_TOKEN_ATTRIBUTE)으로 저장.
        session.setAttribute(CSRF_TOKEN_ATTRIBUTE, token);
        // 생성된 토큰을 반환.
        return token;
    }

    // 요청으로부터 전달된 CSRF 토큰이 세션에 저장된 토큰과 일치하는지 검증하는 메서드.
    public static boolean validateCsrfToken(HttpServletRequest request, String token) {
        // 요청으로부터 세션을 가져옴. 세션이 없으면 null을 반환.
        HttpSession session = request.getSession(false);
        if (session == null) {
            // 세션이 없으면 토큰 검증에 실패한 것으로 간주.
            return false;
        }
        // 세션에서 저장된 CSRF 토큰을 가져옴.
        String sessionToken = (String) session.getAttribute(CSRF_TOKEN_ATTRIBUTE);
        // 세션에 저장된 토큰이 null이 아니고, 요청에서 전달된 토큰과 일치하면 true 반환.
        return sessionToken != null && sessionToken.equals(token);
    }

    // 랜덤한 CSRF 토큰을 생성하는 메서드.
    private static String generateRandomToken() {
        // 32바이트 크기의 랜덤 바이트 배열을 생성.
        byte[] randomBytes = new byte[32];
        // 랜덤 바이트를 생성하여 배열에 채움.
        secureRandom.nextBytes(randomBytes);
        // 바이트 배열을 URL-safe Base64 문자열로 인코딩하여 반환.
        return Base64.getUrlEncoder().encodeToString(randomBytes);
    }
}
