package ktc.secure.coding.controller;


import ktc.secure.coding.util.CsrfTokenUtil;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class FormController {

    // GET 요청을 처리하여 폼을 표시하는 메서드.
    @GetMapping("/form")
    public String showForm(HttpServletRequest request, Model model) {
        // 새로운 CSRF 토큰을 생성하고, 세션에 저장하며 반환.
        String csrfToken = CsrfTokenUtil.generateCsrfToken(request);
        // 모델에 사용자 ID와 CSRF 토큰을 추가하여 뷰에서 사용할 수 있도록 함.
        model.addAttribute("userId", 12345);
        model.addAttribute("csrfToken", csrfToken);
        // "form" 뷰를 반환하여 폼을 표시.
        return "form";
    }

    // POST 요청을 처리하여 폼 제출을 처리하는 메서드.
    @PostMapping("/submit")
    public String handleSubmit(
            HttpServletRequest request,
            @RequestParam("userId") int userId,
            @RequestParam("csrfToken") String csrfToken,
            @RequestParam(value = "_charset_", required = false) String charset,
            Model model) {

        // CSRF 토큰 검증
        if (!CsrfTokenUtil.validateCsrfToken(request, csrfToken)) {
            // 토큰이 유효하지 않으면 에러 메시지를 모델에 추가하고 "error" 뷰를 반환.
            model.addAttribute("message", "Invalid CSRF Token");
            return "error";
        }

        // User ID 검증
        if (!isValidUserId(userId)) {
            // 사용자 ID가 유효하지 않으면 에러 메시지를 모델에 추가하고 "error" 뷰를 반환.
            model.addAttribute("message", "Invalid User ID");
            return "error";
        }

        // Charset 확인
        if (charset != null) {
            // charset이 존재하는 경우, 메시지에 charset을 포함하여 모델에 추가.
            model.addAttribute("message", "Form submitted successfully with userId: " + userId + " and charset: " + charset);
        } else {
            // charset이 없는 경우, 메시지에 userId만 포함하여 모델에 추가.
            model.addAttribute("message", "Form submitted successfully with userId: " + userId);
        }

        // "result" 뷰를 반환하여 결과를 표시.
        return "result";
    }

    // 사용자 ID가 유효한지 확인하는 메서드.
    private boolean isValidUserId(int userId) {
        // 실제 애플리케이션에서는 데이터베이스나 다른 저장소를 통해 유효성을 검증해야 함.
        // 여기서는 예제로 간단한 범위 체크를 수행.
        return userId > 0 && userId <= 100000; // 예시로 1부터 100000까지의 ID만 유효하다고 가정.
    }
}
