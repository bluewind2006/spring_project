package ktc.secure.coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtcSecuecodingResourceCloseSecurityCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtcSecuecodingResourceCloseSecurityCaseApplication.class, args);
	}

}
