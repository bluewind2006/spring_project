package ktc.secure.coding.utils;

import java.io.Closeable;
import java.io.IOException;
import java.nio.channels.Channel;
import java.nio.ByteBuffer;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

//ResourceUtil 클래스는 다양한 자원을 안전하게 닫기 위한 유틸리티 메서드들을 제공하는 클래스입니다.
public class ResourceUtil {

 // Logger 객체를 사용하여 로그를 기록합니다.
 private static final Logger logger = Logger.getLogger(ResourceUtil.class.getName());

 /**
  * JDBC Connection을 닫습니다.
  * @param conn 닫을 Connection 객체
  */
 public static void close(Connection conn) {
     if (conn != null) {
         try {
             conn.close();
         } catch (SQLException e) {
             // Connection을 닫는 동안 발생한 예외를 로그로 기록합니다.
             logger.log(Level.SEVERE, "Connection 닫기 실패", e);
         }
     }
 }

 /**
  * JDBC Statement를 닫습니다.
  * @param stmt 닫을 Statement 객체
  */
 public static void close(Statement stmt) {
     if (stmt != null) {
         try {
             stmt.close();
         } catch (SQLException e) {
             // Statement를 닫는 동안 발생한 예외를 로그로 기록합니다.
             logger.log(Level.SEVERE, "Statement 닫기 실패", e);
         }
     }
 }

 /**
  * JDBC ResultSet을 닫습니다.
  * @param rs 닫을 ResultSet 객체
  */
 public static void close(ResultSet rs) {
     if (rs != null) {
         try {
             rs.close();
         } catch (SQLException e) {
             // ResultSet을 닫는 동안 발생한 예외를 로그로 기록합니다.
             logger.log(Level.SEVERE, "ResultSet 닫기 실패", e);
         }
     }
 }

 /**
  * InputStream, OutputStream, Reader, Writer 등 Closeable 인터페이스를 구현한 리소스를 닫습니다.
  * @param closeable 닫을 리소스
  */
 public static void close(Closeable closeable) {
     if (closeable != null) {
         try {
             closeable.close();
         } catch (IOException e) {
             // Closeable 리소스를 닫는 동안 발생한 예외를 로그로 기록합니다.
             logger.log(Level.SEVERE, "Closeable 리소스 닫기 실패", e);
         }
     }
 }

 /**
  * Socket을 닫습니다.
  * @param socket 닫을 Socket 객체
  */
 public static void close(Socket socket) {
     if (socket != null) {
         try {
             socket.close();
         } catch (IOException e) {
             // Socket을 닫는 동안 발생한 예외를 로그로 기록합니다.
             logger.log(Level.SEVERE, "Socket 닫기 실패", e);
         }
     }
 }

 /**
  * NIO Channel을 닫습니다.
  * @param channel 닫을 Channel 객체
  */
 public static void close(Channel channel) {
     if (channel != null) {
         try {
             channel.close();
         } catch (IOException e) {
             // Channel을 닫는 동안 발생한 예외를 로그로 기록합니다.
             logger.log(Level.SEVERE, "Channel 닫기 실패", e);
         }
     }
 }

 /**
  * ByteBuffer를 클리어합니다.
  * @param buffer 클리어할 ByteBuffer 객체
  */
 public static void clear(ByteBuffer buffer) {
     if (buffer != null) {
         buffer.clear();  // ByteBuffer의 위치를 0으로 설정하고 제한을 용량으로 설정합니다.
     }
 }

 /**
  * Thread를 인터럽트합니다.
  * @param thread 인터럽트할 Thread 객체
  */
 public static void interrupt(Thread thread) {
     if (thread != null) {
         thread.interrupt();  // 주어진 스레드에 인터럽트 신호를 보냅니다.
     }
 }

 /**
  * 여러 리소스를 닫습니다. 가변 인자(AutoCloseable...)를 사용하여 여러 리소스를 처리할 수 있습니다.
  * @param resources 닫을 리소스들
  */
 public static void close(AutoCloseable... resources) {
     for (var resource : resources) {
         if (resource != null) {
             try {
                 resource.close();
             } catch (SQLException e) {
                 // SQL 관련 리소스를 닫는 동안 발생한 예외를 로그로 기록합니다.
                 logger.log(Level.SEVERE, "SQL 리소스 닫기 실패", e);
             } catch (IOException e) {
                 // IO 관련 리소스를 닫는 동안 발생한 예외를 로그로 기록합니다.
                 logger.log(Level.SEVERE, "IO 리소스 닫기 실패", e);
             } catch (Exception e) {
                 // 기타 리소스를 닫는 동안 발생한 예외를 로그로 기록합니다.
                 logger.log(Level.SEVERE, "리소스 닫기 실패", e);
             }
         }
     }
 }

 /**
  * try-with-resources 유틸리티 메서드를 사용하여 리소스를 안전하게 처리합니다.
  * @param action 리소스를 사용하여 실행할 작업
  * @param resources 작업 후 닫을 리소스들
  * @param <T> 실행 중 발생할 수 있는 예외 유형
  * @throws T 작업 중 발생한 예외
  */
 public static <T extends Throwable> void tryWithResources(ResourceAction<T> action, AutoCloseable... resources) throws T {
     try {
         action.execute();  // 지정된 작업을 실행합니다.
     } finally {
         close(resources);  // 작업이 완료되면 리소스들을 닫습니다.
     }
 }

 // ResourceAction 인터페이스는 실행할 작업을 정의하는 함수형 인터페이스입니다.
 // 이 인터페이스를 구현하여 특정 작업을 실행할 수 있습니다.
 @FunctionalInterface
 public interface ResourceAction<T extends Throwable> {
     void execute() throws T;  // 작업을 실행하는 메서드
 }
}
