package ktc.secure.coding.utils;


import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ResourceUtilTests {

    @Test
    void testCloseConnection() {
        Connection conn = mock(Connection.class);
        try {
            ResourceUtil.close(conn);
            verify(conn).close();
        } catch (SQLException e) {
            fail("예외가 발생해서는 안됩니다.");
        }
    }

    @Test
    void testCloseStatement() {
        Statement stmt = mock(Statement.class);
        try {
            ResourceUtil.close(stmt);
            verify(stmt).close();
        } catch (SQLException e) {
            fail("예외가 발생해서는 안됩니다.");
        }
    }

    @Test
    void testCloseInputStream() {
        try (var outputStream = new PipedOutputStream();
             var inputStream = new PipedInputStream(outputStream)) {
            ResourceUtil.close(inputStream);
            assertThrows(IOException.class, inputStream::read, "IOException이 발생해야 합니다.");
        } catch (IOException e) {
            fail("예외가 발생해서는 안됩니다.");
        }
    }

    @Test
    void testTryWithResources() {
        try {
            ResourceUtil.tryWithResources(() -> {
                Connection conn = mock(Connection.class);
                try (conn) {
                    assertNotNull(conn);
                } catch (SQLException e) {
                    throw new RuntimeException("SQL 실행 오류", e);
                }
            });
        } catch (Throwable t) {
            fail("예외가 발생해서는 안됩니다.");
        }
    }
}
