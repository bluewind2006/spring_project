package ktc.secure.coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtcSecuecodingUrlParameterSecurityCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtcSecuecodingUrlParameterSecurityCaseApplication.class, args);
	}

}
