package ktc.secure.coding.controller;

import ktc.secure.coding.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private OrderService orderService;

    @GetMapping("/addProduct")
    public String addProductPage(HttpServletRequest request) {
        // 현재 요청의 세션을 가져옴. 세션이 없으면 null을 반환.
        HttpSession session = request.getSession(false);
        // 세션이 없거나 세션에 "user" 속성이 없으면 로그인 페이지로 리다이렉트.
        if (session == null || session.getAttribute("user") == null) {
            return "redirect:/login";
        }

        // 세션에서 "user" 속성을 가져와 사용자 역할을 확인.
        String userRole = (String) session.getAttribute("user");
        // 사용자 역할이 "admin"이 아니면 접근 권한이 없음을 알리고 예외를 발생시킴.
        if (!"admin".equals(userRole)) {
            throw new IllegalArgumentException("Unauthorized access");
        }
        // "addProduct" 뷰(예: addProduct.html)를 반환하여 제품 추가 페이지를 렌더링.
        return "addProduct";
    }

    @PostMapping("/addProduct")
    public String addProduct(@RequestParam("productId") String productId, HttpServletRequest request) {
        // 현재 요청의 세션을 가져옴. 세션이 없으면 null을 반환.
        HttpSession session = request.getSession(false);
        // 세션이 없거나 세션에 "user" 속성이 없으면 로그인 페이지로 리다이렉트.
        if (session == null || session.getAttribute("user") == null) {
            return "redirect:/login";
        }

        // 세션에서 "user" 속성을 가져와 사용자 역할을 확인.
        String userRole = (String) session.getAttribute("user");
        // OrderService를 통해 제품을 추가. 제품 ID와 사용자 역할을 전달.
        orderService.addProduct(productId, userRole);
        // 제품 추가 후 다시 "addProduct" 페이지로 리다이렉트.
        return "redirect:/admin/addProduct";
    }
}
