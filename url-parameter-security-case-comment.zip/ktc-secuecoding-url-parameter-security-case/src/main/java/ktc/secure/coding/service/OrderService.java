package ktc.secure.coding.service;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    private List<String> products = new ArrayList<>();

    public String addProduct(String productId, String userRole) {
        if (productId == null || productId.isEmpty()) {
            throw new IllegalArgumentException("Invalid product ID");
        }
        if (!"admin".equals(userRole)) {
            throw new IllegalArgumentException("Unauthorized access");
        }
        products.add(productId);
        return "Product added: " + productId;
    }

    public String selectProduct(String productId, String userRole) {
        if (productId == null || productId.isEmpty()) {
            throw new IllegalArgumentException("Invalid product ID");
        }
        if (!"user".equals(userRole) && !"admin".equals(userRole)) {
            throw new IllegalArgumentException("Unauthorized access");
        }
        if (!products.contains(productId)) {
            throw new IllegalArgumentException("Product not found");
        }
        return "Product selected: " + productId;
    }

    public String confirmOrder(String productId, String userRole) {
        if (productId == null || productId.isEmpty()) {
            throw new IllegalArgumentException("No product selected");
        }
        if (!"user".equals(userRole) && !"admin".equals(userRole)) {
            throw new IllegalArgumentException("Unauthorized access");
        }
        return "Order confirmed for product: " + productId;
    }

    public List<String> getProducts() {
        return products;
    }
}