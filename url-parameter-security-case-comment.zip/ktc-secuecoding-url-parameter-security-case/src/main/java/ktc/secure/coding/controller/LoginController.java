package ktc.secure.coding.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class LoginController {

    // 로그인 페이지를 표시하거나 이미 로그인된 사용자를 적절한 페이지로 리다이렉트하는 메서드.
    @GetMapping("/login")
    public String loginPage(HttpServletRequest request) {
        // 현재 요청에 대한 세션을 가져옴. 세션이 존재하지 않으면 null을 반환.
        HttpSession session = request.getSession(false);
        
        // 세션이 존재하고, 세션에 "user" 속성이 있는 경우.
        if (session != null && session.getAttribute("user") != null) {
            // 세션에서 사용자 역할을 가져옴.
            String userRole = (String) session.getAttribute("user");
            
            // 사용자가 "admin" 역할이면, 관리자의 제품 추가 페이지로 리다이렉트.
            if ("admin".equals(userRole)) {
                return "redirect:/admin/addProduct";
            } 
            // 사용자가 "user" 역할이면, 일반 사용자의 제품 선택 페이지로 리다이렉트.
            else if ("user".equals(userRole)) {
                return "redirect:/order/selectProduct";
            }
        }
        
        // 세션이 없거나 사용자가 로그인되지 않은 경우, 로그인 페이지를 반환.
        return "login"; // "login.html" 뷰를 렌더링.
    }

    // 사용자의 로그인 요청을 처리하는 메서드.
    @PostMapping("/login")
    public String login(@RequestParam("username") String username, 
                        @RequestParam("password") String password, 
                        HttpServletRequest request) {
        // 사용자 이름과 비밀번호를 검증.
        if ("admin".equals(username) && "password".equals(password)) {
            // 관리자로 인증되면 세션에 "admin" 역할을 저장하고 관리자 페이지로 리다이렉트.
            request.getSession().setAttribute("user", "admin");
            return "redirect:/admin/addProduct";
        } 
        else if ("user".equals(username) && "password".equals(password)) {
            // 일반 사용자로 인증되면 세션에 "user" 역할을 저장하고 사용자 페이지로 리다이렉트.
            request.getSession().setAttribute("user", "user");
            return "redirect:/order/selectProduct";
        }
        
        // 인증에 실패한 경우, 로그인 페이지로 리다이렉트하며 오류 메시지를 전달.
        return "redirect:/login?error";
    }

    // 사용자의 로그아웃 요청을 처리하는 메서드.
    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        // 현재 요청에 대한 세션을 가져옴. 세션이 존재하지 않으면 null을 반환.
        HttpSession session = request.getSession(false);
        
        // 세션이 존재하면 세션을 무효화하여 로그아웃 처리.
        if (session != null) {
            session.invalidate(); // 세션 무효화 (로그아웃 처리)
        }
        
        // 로그아웃 후 로그인 페이지로 리다이렉트.
        return "redirect:/login";
    }
}
