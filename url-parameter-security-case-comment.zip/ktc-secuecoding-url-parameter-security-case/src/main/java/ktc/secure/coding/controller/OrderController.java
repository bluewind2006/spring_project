package ktc.secure.coding.controller;

import ktc.secure.coding.service.OrderService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.util.List;

@Controller
@RequestMapping("/order")
public class OrderController {

    // OrderService를 주입받음. 이 서비스는 주문 처리와 관련된 비즈니스 로직을 담당.
    @Autowired
    private OrderService orderService;

    // 제품 선택 페이지를 보여주는 메서드.
    @GetMapping("/selectProduct")
    public String selectProductPage(HttpServletRequest request, Model model) {
        // 현재 요청에 대한 세션을 가져옴. 세션이 없으면 null을 반환.
        HttpSession session = request.getSession(false);
        // 세션이 없거나 "user" 속성이 없으면 로그인 페이지로 리다이렉트.
        if (session == null || session.getAttribute("user") == null) {
            return "redirect:/login";
        }

        // 세션에서 사용자 역할을 가져옴.
        String userRole = (String) session.getAttribute("user");
        // 사용자 역할이 "user" 또는 "admin"이 아니면 예외 발생.
        if (!"user".equals(userRole) && !"admin".equals(userRole)) {
            throw new IllegalArgumentException("Unauthorized access");
        }

        // OrderService를 통해 현재 선택 가능한 제품 리스트를 가져옴.
        List<String> products = orderService.getProducts();
        // 모델에 제품 리스트를 추가하여 뷰에서 사용 가능하도록 함.
        model.addAttribute("products", products);
        // "selectProduct.html" 뷰를 반환.
        return "selectProduct";
    }

    // 제품을 선택한 후 다음 단계로 진행하는 메서드.
    @PostMapping("/selectProduct")
    public String selectProduct(@RequestParam("productId") String productId, HttpServletRequest request) {
        // 현재 요청에 대한 세션을 가져옴. 세션이 없으면 null을 반환.
        HttpSession session = request.getSession(false);
        // 세션이 없거나 "user" 속성이 없으면 로그인 페이지로 리다이렉트.
        if (session == null || session.getAttribute("user") == null) {
            return "redirect:/login";
        }

        // 세션에서 사용자 역할을 가져옴.
        String userRole = (String) session.getAttribute("user");
        // 선택한 제품 ID를 세션에 저장.
        request.getSession().setAttribute("productId", productId);
        // 선택한 제품을 OrderService를 통해 처리.
        orderService.selectProduct(productId, userRole);
        // 주문 확인 페이지로 리다이렉트.
        return "redirect:/order/confirmOrder";
    }

    // 주문 확인 페이지를 보여주는 메서드.
    @GetMapping("/confirmOrder")
    public String confirmOrderPage(HttpServletRequest request) {
        // 현재 요청에 대한 세션을 가져옴. 세션이 없으면 null을 반환.
        HttpSession session = request.getSession(false);
        // 세션이 없거나 "user" 속성이 없으면 로그인 페이지로 리다이렉트.
        if (session == null || session.getAttribute("user") == null) {
            return "redirect:/login";
        }

        // 세션에서 사용자 역할과 선택한 제품 ID를 가져옴.
        String userRole = (String) session.getAttribute("user");
        String productId = (String) session.getAttribute("productId");

        // 제품 ID가 없거나 비어있으면 예외 발생.
        if (productId == null || productId.isEmpty()) {
            throw new IllegalArgumentException("No product selected");
        }

        // 추가적인 검증 로직: 이전 단계에서 선택한 제품을 확인.
        orderService.confirmOrder(productId, userRole);

        // "confirmOrder.html" 뷰를 반환.
        return "confirmOrder";
    }

    // 주문을 최종적으로 확인하고 완료하는 메서드.
    @PostMapping("/confirmOrder")
    public String confirmOrder(HttpServletRequest request) {
        // 현재 요청에 대한 세션을 가져옴. 세션이 없으면 null을 반환.
        HttpSession session = request.getSession(false);
        // 세션이 없거나 "user" 속성이 없으면 로그인 페이지로 리다이렉트.
        if (session == null || session.getAttribute("user") == null) {
            return "redirect:/login";
        }

        // 세션에서 선택한 제품 ID와 사용자 역할을 가져옴.
        String productId = (String) session.getAttribute("productId");
        String userRole = (String) session.getAttribute("user");

        // 제품 ID가 없거나 비어있으면 예외 발생.
        if (productId == null || productId.isEmpty()) {
            throw new IllegalArgumentException("No product selected");
        }

        // 최종 단계에서 이전 단계의 선택된 제품을 확인하고 주문을 처리.
        orderService.confirmOrder(productId, userRole);
        // 주문 완료 페이지로 리다이렉트.
        return "redirect:/order/completeOrder";
    }

    // 주문 완료 페이지를 보여주는 메서드.
    @GetMapping("/completeOrder")
    public String completeOrderPage(HttpServletRequest request) {
        // 현재 요청에 대한 세션을 가져옴. 세션이 없으면 null을 반환.
        HttpSession session = request.getSession(false);
        // 세션이 없거나 "user" 속성이 없으면 로그인 페이지로 리다이렉트.
        if (session == null || session.getAttribute("user") == null) {
            return "redirect:/login";
        }

        // 세션에서 선택한 제품 ID를 가져옴.
        String productId = (String) session.getAttribute("productId");
        // 제품 ID가 없거나 비어있으면 예외 발생.
        if (productId == null || productId.isEmpty()) {
            throw new IllegalArgumentException("No product selected");
        }
        // "completeOrder.html" 뷰를 반환.
        return "completeOrder";
    }
}
