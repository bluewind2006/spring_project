package ktc.secure.coding;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void whenValidUserIdAndRole_thenSuccess() throws Exception {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", "user");

        mockMvc.perform(get("/user/1").session(session))
               .andExpect(status().isOk())
               .andExpect(content().string("User ID: 1"));
    }

    @Test
    public void whenInvalidUserId_thenBadRequest() throws Exception {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", "user");

        mockMvc.perform(get("/user/0").session(session))
               .andExpect(status().isBadRequest())
               .andExpect(content().string("Validation error: must be greater than or equal to 1"));
    }

    @Test
    public void whenValidAdminRole_thenSuccess() throws Exception {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", "admin");

        mockMvc.perform(get("/admin/addProduct").session(session))
               .andExpect(status().isOk());
    }

    @Test
    public void whenInvalidAdminRole_thenUnauthorized() throws Exception {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", "user");

        mockMvc.perform(get("/admin/addProduct").session(session))
               .andExpect(status().isBadRequest())
               .andExpect(content().string("Unauthorized access"));
    }

    @Test
    public void whenValidInput_thenSanitized() throws Exception {
        mockMvc.perform(get("/validate").param("input", "<script>alert('xss')</script>"))
               .andExpect(status().isOk())
               .andExpect(content().string("Validated Input: &lt;script&gt;alert(&#39;xss&#39;)&lt;/script&gt;"));
    }
}
