package ktc.secure.coding.util;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class OverflowCheckerTest {

    @Test
    void testSafeAdd_NoOverflow() {
        assertDoesNotThrow(() -> {
            int result = OverflowChecker.safeAdd(100, 200);
            assertEquals(300, result);
        });
    }

    @Test
    void testSafeAdd_PositiveOverflow() {
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> {
            OverflowChecker.safeAdd(Integer.MAX_VALUE, 1);
        });
        assertEquals("오버플로우 발생: " + Integer.MAX_VALUE + " + 1", thrown.getMessage());
    }

    @Test
    void testSafeAdd_NegativeOverflow() {
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> {
            OverflowChecker.safeAdd(Integer.MIN_VALUE, -1);
        });
        assertEquals("언더플로우 발생: " + Integer.MIN_VALUE + " + -1", thrown.getMessage());
    }

    @Test
    void testSafeSubtract_NoOverflow() {
        assertDoesNotThrow(() -> {
            int result = OverflowChecker.safeSubtract(200, 100);
            assertEquals(100, result);
        });
    }

    @Test
    void testSafeSubtract_PositiveOverflow() {
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> {
            OverflowChecker.safeSubtract(Integer.MIN_VALUE, 1);
        });
        assertEquals("언더플로우 발생: " + Integer.MIN_VALUE + " - 1", thrown.getMessage());
    }

    @Test
    void testSafeSubtract_NegativeOverflow() {
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> {
            OverflowChecker.safeSubtract(Integer.MAX_VALUE, -1);
        });
        assertEquals("오버플로우 발생: " + Integer.MAX_VALUE + " - -1", thrown.getMessage());
    }

    @Test
    void testSafeMultiply_NoOverflow() {
        assertDoesNotThrow(() -> {
            int result = OverflowChecker.safeMultiply(10, 20);
            assertEquals(200, result);
        });
    }

    @Test
    void testSafeMultiply_PositiveOverflow() {
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> {
            OverflowChecker.safeMultiply(Integer.MAX_VALUE / 2, 3);
        });
        assertEquals("오버플로우 발생: " + (Integer.MAX_VALUE / 2) + " * 3", thrown.getMessage());
    }

    @Test
    void testSafeMultiply_NegativeOverflow() {
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> {
            OverflowChecker.safeMultiply(Integer.MIN_VALUE, 2);
        });
        assertEquals("언더플로우 발생: " + Integer.MIN_VALUE + " * 2", thrown.getMessage());
    }

    @Test
    void testSafeMultiply_Zero() {
        assertDoesNotThrow(() -> {
            int result = OverflowChecker.safeMultiply(10, 0);
            assertEquals(0, result);
        });
    }

    @Test
    void testSafeDivide_NoOverflow() {
        assertDoesNotThrow(() -> {
            int result = OverflowChecker.safeDivide(200, 10);
            assertEquals(20, result);
        });
    }

    @Test
    void testSafeDivide_DivideByZero() {
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> {
            OverflowChecker.safeDivide(200, 0);
        });
        assertEquals("0으로 나눌 수 없습니다: 200 / 0", thrown.getMessage());
    }

    @Test
    void testSafeDivide_PositiveOverflow() {
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> {
            OverflowChecker.safeDivide(Integer.MIN_VALUE, -1);
        });
        assertEquals("오버플로우 발생: " + Integer.MIN_VALUE + " / -1", thrown.getMessage());
    }
}