package ktc.secure.coding.util;

public class OverflowChecker {

    // 두 정수의 덧셈을 안전하게 수행하는 메서드.
    // 덧셈 결과가 오버플로우 또는 언더플로우를 초래할 경우 예외를 발생시킴.
    public static int safeAdd(int x, int y) {
        // 두 양수의 합이 Integer.MAX_VALUE를 초과할 경우 오버플로우 발생.
        if (x > 0 && y > 0 && x > Integer.MAX_VALUE - y) {
            throw new ArithmeticException("오버플로우 발생: " + x + " + " + y);
        }
        // 두 음수의 합이 Integer.MIN_VALUE보다 작을 경우 언더플로우 발생.
        if (x < 0 && y < 0 && x < Integer.MIN_VALUE - y) {
            throw new ArithmeticException("언더플로우 발생: " + x + " + " + y);
        }
        // 위 조건을 모두 통과하면 안전하게 덧셈을 수행.
        return x + y;
    }

    // 두 정수의 뺄셈을 안전하게 수행하는 메서드.
    // 뺄셈 결과가 오버플로우 또는 언더플로우를 초래할 경우 예외를 발생시킴.
    public static int safeSubtract(int x, int y) {
        // 양수 y를 뺐을 때 결과가 Integer.MIN_VALUE보다 작을 경우 언더플로우 발생.
        if (y > 0 && x < Integer.MIN_VALUE + y) {
            throw new ArithmeticException("언더플로우 발생: " + x + " - " + y);
        }
        // 음수 y를 뺐을 때 결과가 Integer.MAX_VALUE를 초과할 경우 오버플로우 발생.
        if (y < 0 && x > Integer.MAX_VALUE + y) {
            throw new ArithmeticException("오버플로우 발생: " + x + " - " + y);
        }
        // 위 조건을 모두 통과하면 안전하게 뺄셈을 수행.
        return x - y;
    }

    // 두 정수의 곱셈을 안전하게 수행하는 메서드.
    // 곱셈 결과가 오버플로우 또는 언더플로우를 초래할 경우 예외를 발생시킴.
    public static int safeMultiply(int x, int y) {
        // x 또는 y가 0일 경우 결과는 항상 0이므로, 계산을 바로 종료.
        if (x == 0 || y == 0) {
            return 0;
        }
        // x 또는 y가 Integer.MIN_VALUE이고 다른 피연산자가 -1일 경우 오버플로우 발생.
        if (x == -1 && y == Integer.MIN_VALUE || y == -1 && x == Integer.MIN_VALUE) {
            throw new ArithmeticException("오버플로우 발생: " + x + " * " + y);
        }
        // 두 양수의 곱셈이 Integer.MAX_VALUE를 초과할 경우 오버플로우 발생.
        if (x > 0 && y > 0 && x > Integer.MAX_VALUE / y) {
            throw new ArithmeticException("오버플로우 발생: " + x + " * " + y);
        }
        // 양수 x와 음수 y의 곱셈이 Integer.MIN_VALUE보다 작을 경우 언더플로우 발생.
        if (x > 0 && y < 0 && y < Integer.MIN_VALUE / x) {
            throw new ArithmeticException("언더플로우 발생: " + x + " * " + y);
        }
        // 음수 x와 양수 y의 곱셈이 Integer.MIN_VALUE보다 작을 경우 언더플로우 발생.
        if (x < 0 && y > 0 && x < Integer.MIN_VALUE / y) {
            throw new ArithmeticException("언더플로우 발생: " + x + " * " + y);
        }
        // 두 음수의 곱셈이 Integer.MAX_VALUE를 초과할 경우 오버플로우 발생.
        if (x < 0 && y < 0 && x < Integer.MAX_VALUE / y) {
            throw new ArithmeticException("오버플로우 발생: " + x + " * " + y);
        }
        // 위 조건을 모두 통과하면 안전하게 곱셈을 수행.
        return x * y;
    }

    // 두 정수의 나눗셈을 안전하게 수행하는 메서드.
    // 나눗셈 결과가 오버플로우를 초래하거나 0으로 나누려 할 경우 예외를 발생시킴.
    public static int safeDivide(int x, int y) {
        // 나누는 값이 0이면 ArithmeticException을 발생시킴.
        if (y == 0) {
            throw new ArithmeticException("0으로 나눌 수 없습니다: " + x + " / " + y);
        }
        // x가 Integer.MIN_VALUE이고 y가 -1인 경우 오버플로우 발생.
        if (x == Integer.MIN_VALUE && y == -1) {
            throw new ArithmeticException("오버플로우 발생: " + x + " / " + y);
        }
        // 위 조건을 모두 통과하면 안전하게 나눗셈을 수행.
        return x / y;
    }
}
