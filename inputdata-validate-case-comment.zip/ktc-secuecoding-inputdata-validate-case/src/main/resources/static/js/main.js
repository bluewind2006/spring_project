import { validateForm } from '/js/validateForm.js';

document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#userForm');
  form.addEventListener('submit', (event) => {
    const isValid = validateForm(form);
    if (!isValid) {
      event.preventDefault(); // 폼이 유효하지 않은 경우에만 기본 동작 방지
      console.log('Form validation failed');
    } else {
      console.log('Form validation passed');
    }
  });
});
