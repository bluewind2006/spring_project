import Validator from '/js/Validator.js';

function showInvalidMessage(element, message) {
  const errorElement = document.createElement('span');
  errorElement.className = 'error-message';
  errorElement.innerText = message;
  element.parentNode.appendChild(errorElement);
}

export function validateForm(form) {
  let isAllValid = true;

  const clearMessages = () => {
    const errorMessages = form.querySelectorAll('.error-message');
    errorMessages.forEach(msg => msg.remove());
  };

  clearMessages();

  const validators = [
    { field: form.email, type: 'email', message: '이메일 주소가 형식에 맞지 않습니다.' },
    { field: form.cellPhoneNo, type: 'cellphone', message: '핸드폰 번호가 형식에 맞지 않습니다.' },
    { field: form.url, type: 'url', message: 'URL이 형식에 맞지 않습니다.' },
    { field: form.creditCardNo, type: 'credit-card', message: '신용카드 번호가 형식에 맞지 않습니다.' },
    { field: form.bankAccountNo, type: 'bank-account', message: '계좌번호가 형식에 맞지 않습니다.' },
    { field: form.ssn, type: 'ssn', message: '주민등록번호가 형식에 맞지 않습니다.' }
  ];

  validators.forEach(validator => {
    if (!Validator.validate(validator.field.value, validator.type)) {
      showInvalidMessage(validator.field, validator.message);
      isAllValid = false;
    }
  });

  return isAllValid;
}
