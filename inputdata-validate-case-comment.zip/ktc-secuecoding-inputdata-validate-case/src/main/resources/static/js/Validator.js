// Validator 클래스 정의
class Validator {
  // 생성자: Validator 클래스의 인스턴스가 생성될 때 호출됩니다.
  constructor() {
    // validateFunctions는 각 유효성 검사 타입에 대한 검증 함수를 저장하는 객체입니다.
    this.validateFunctions = {};
    
    // 초기화 메서드 호출: 기본적인 유효성 검사 함수들을 설정합니다.
    this.initValidators();
  }

  // validate 메서드: 특정 값이 주어진 타입의 유효성 검사를 통과하는지 확인합니다.
  validate(value, type) {
    // 입력된 value에서 앞뒤 공백을 제거합니다.
    const val = value.trim();
    
    // type이 없으면 유효성 검사를 하지 않고 true를 반환합니다.
    if (!type) return true;

    // type에 해당하는 유효성 검사 함수를 가져옵니다.
    const validateFunc = this.validateFunctions[type];
    
    // 유효성 검사 함수가 존재하면 그 함수를 호출해 검사하고, 없으면 true를 반환합니다.
    return validateFunc ? validateFunc(val) : true;
  }

  // setValidator 메서드: 새로운 유효성 검사 함수를 설정합니다.
  setValidator(type, func) {
    // type이 문자열이 아니면 에러를 발생시킵니다.
    if (typeof type !== 'string') {
      throw new Error('type parameter must be a string');
    }
    
    // func가 함수가 아니면 에러를 발생시킵니다.
    if (typeof func !== 'function') {
      throw new Error('func parameter must be a function');
    }
    
    // type에 해당하는 유효성 검사 함수를 validateFunctions 객체에 저장합니다.
    this.validateFunctions[type] = func;
  }

  // initValidators 메서드: 여러 기본 유효성 검사 함수들을 설정합니다.
  initValidators() {
    // 'cellphone' 타입의 유효성 검사 함수 설정
    this.setValidator('cellphone', function (phoneNo) {
      // 전화번호가 비어 있으면 false 반환
      if (!phoneNo) return false;
      
      // 한국 휴대폰 번호 형식에 맞는지 검사
      return !!phoneNo.match(/^01[016789]-[0-9]{3,4}-[0-9]{4}$/);
    });

    // 'email' 타입의 유효성 검사 함수 설정
    this.setValidator('email', function (email) {
      // 이메일이 비어 있으면 false 반환
      if (!email) return false;
      
      // 일반적인 이메일 형식에 맞는지 검사
      return !!email.match(/^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i);
    });

    // 'url' 타입의 유효성 검사 함수 설정
    this.setValidator('url', function (url) {
      // URL이 비어 있으면 false 반환
      if (!url) return false;
      
      // 일반적인 URL 형식에 맞는지 검사
      return !!url.match(/^(?:(http|https|ftp|mailto):\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:\/?#[\]@!\$&'\(\)\*\+,;=]+$/i);
    });

    // 'credit-card' 타입의 유효성 검사 함수 설정
    this.setValidator('credit-card', function (cardNo) {
      // 신용카드 번호가 비어 있으면 false 반환
      if (!cardNo) return false;
      
      // 신용카드 번호 형식에 맞는지 검사 (앞자리 3, 4, 5, 6, 9로 시작)
      return !!cardNo.match(/^[34569][0-9]{3}-[0-9]{4}-[0-9]{4}-[0-9]{4}$/);
    });

    // 'bank-account' 타입의 유효성 검사 함수 설정
    this.setValidator('bank-account', function (accountNo) {
      // 은행 계좌 번호가 비어 있으면 false 반환
      if (!accountNo) return false;
      
      // 다양한 은행 계좌 번호 형식에 맞는지 검사
      return !!accountNo.match(/^([0-9]{2}-[0-9]{2}-[0-9]{6}|[0-9]{3}-([0-9]{5,6}-[0-9]{3}|[0-9]{6}-[0-9]{5}|[0-9]{2,3}-[0-9]{6}|[0-9]{2}-[0-9]{7}|[0-9]{2}-[0-9]{4,6}-[0-9]|[0-9]{5}-[0-9]{3}-[0-9]{2}|[0-9]{2}-[0-9]{5}-[0-9]{3}|[0-9]{4}-[0-9]{4}-[0-9]{3}|[0-9]{6}-[0-9]{2}-[0-9]{3}|[0-9]{2}-[0-9]{2}-[0-9]{7})|[0-9]{4}-([0-9]{3}-[0-9]{6}|[0-9]{2}-[0-9]{6}-[0-9])|[0-9]{5}-[0-9]{2}-[0-9]{6}|[0-9]{6}-[0-9]{2}-[0-9]{5,6})$/);
    });

    // 'ssn' 타입의 유효성 검사 함수 설정
    this.setValidator('ssn', function (ssn) {
      // 주민등록번호가 비어 있으면 false 반환
      if (!ssn) return false;
      
      // 주민등록번호 형식에 맞는지 검사
      return !!ssn.match(/^\d{6}-?\d{7}$/);
    });
  }
}

// Validator 클래스의 인스턴스를 생성하여 기본적으로 사용할 수 있도록 export 합니다.
export default new Validator();
