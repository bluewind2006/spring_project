package ktc.secure.coding.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

//User 클래스는 Java Record를 사용하여 정의된 불변 객체입니다.
//Record는 Java 16에서 도입된 기능으로, 간결하게 데이터를 저장하는 객체를 정의할 수 있습니다.
//User Record는 이메일, 휴대폰 번호, URL, 신용카드 번호, 은행 계좌 번호, 주민등록번호를 필드로 가집니다.
public record User(

 // 이메일 주소에 대한 필드
 // @Email: 이 필드는 유효한 이메일 형식이어야 함을 나타냅니다. 유효하지 않은 경우 "Invalid email address"라는 메시지를 반환합니다.
 // @NotBlank: 이 필드는 공백일 수 없음을 나타냅니다. 값이 비어있거나 공백일 경우 "Email is required"라는 메시지를 반환합니다.
 @Email(message = "Invalid email address")
 @NotBlank(message = "Email is required")
 String email,

 // 휴대폰 번호에 대한 필드
 // @Pattern: 이 필드는 지정된 정규 표현식에 맞는 형식이어야 합니다. 정규식은 한국의 일반적인 휴대폰 번호 형식을 나타냅니다.
 // 예: 010-1234-5678 형식. 유효하지 않을 경우 "Invalid cell phone number"라는 메시지를 반환합니다.
 // @NotBlank: 이 필드는 공백일 수 없음을 나타냅니다. 값이 비어있거나 공백일 경우 "Cell phone number is required"라는 메시지를 반환합니다.
 @Pattern(regexp = "^01[016789]-[0-9]{3,4}-[0-9]{4}$", message = "Invalid cell phone number")
 @NotBlank(message = "Cell phone number is required")
 String cellPhoneNo,

 // URL에 대한 필드
 // @Pattern: 이 필드는 지정된 정규 표현식에 맞는 URL 형식이어야 합니다. URL 형식에 맞지 않으면 "Invalid URL"이라는 메시지를 반환합니다.
 @Pattern(regexp = "^(?:(http|https|ftp|mailto):\\/\\/)?[\\w.-]+(?:\\.[\\w\\.-]+)+[\\w\\-\\._~:\\/?#\\[\\]@!\\$&'\\(\\)\\*\\+,;=]+$", message = "Invalid URL")
 String url,

 // 신용카드 번호에 대한 필드
 // @Pattern: 이 필드는 지정된 정규 표현식에 맞는 형식이어야 합니다. 정규식은 일반적인 신용카드 번호 형식을 나타냅니다.
 // 예: 1234-5678-1234-5678 형식. 유효하지 않을 경우 "Invalid credit card number"라는 메시지를 반환합니다.
 @Pattern(regexp = "^[34569][0-9]{3}-[0-9]{4}-[0-9]{4}-[0-9]{4}$", message = "Invalid credit card number")
 String creditCardNo,

 // 은행 계좌 번호에 대한 필드
 // @Pattern: 이 필드는 지정된 정규 표현식에 맞는 형식이어야 합니다. 이 정규식은 다양한 은행 계좌 번호 형식을 지원합니다.
 // 유효하지 않을 경우 "Invalid bank account number"라는 메시지를 반환합니다.
 @Pattern(regexp = "^([0-9]{2}-[0-9]{2}-[0-9]{6}|[0-9]{3}-([0-9]{5,6}-[0-9]{3}|[0-9]{6}-[0-9]{5}|[0-9]{2,3}-[0-9]{6}|[0-9]{2}-[0-9]{7}|[0-9]{2}-[0-9]{4,6}-[0-9]|[0-9]{5}-[0-9]{3}-[0-9]{2}|[0-9]{2}-[0-9]{5}-[0-9]{3}|[0-9]{4}-[0-9]{4}-[0-9]{3}|[0-9]{6}-[0-9]{2}-[0-9]{3}|[0-9]{2}-[0-9]{2}-[0-9]{7})|[0-9]{4}-([0-9]{3}-[0-9]{6}|[0-9]{2}-[0-9]{6}-[0-9])|[0-9]{5}-[0-9]{2}-[0-9]{6}|[0-9]{6}-[0-9]{2}-[0-9]{5,6})$", message = "Invalid bank account number")
 String bankAccountNo,

 // 주민등록번호에 대한 필드
 // @Pattern: 이 필드는 지정된 정규 표현식에 맞는 형식이어야 합니다. 정규식은 한국의 주민등록번호 형식을 나타냅니다.
 // 예: 123456-1234567 형식. 유효하지 않을 경우 "Invalid SSN"이라는 메시지를 반환합니다.
 @Pattern(regexp = "^\\d{6}-?\\d{7}$", message = "Invalid SSN")
 String ssn
) {}
