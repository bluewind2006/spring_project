package ktc.secure.coding.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.validation.Valid;
import ktc.secure.coding.dto.User;

@Controller
public class FormController {

    // HTTP GET 요청이 "/" 경로로 들어오면 이 메서드가 호출됨
    @GetMapping("/")
    public String showForm(Model model) {
        // 새로운 User 객체를 생성하고, 이 객체는 폼에서 입력된 데이터를 저장하는 용도로 사용됨
        User user = new User("", "", "", "", "", "");
        
        // 생성된 User 객체를 모델에 추가하여, 뷰(예: index.html)에서 참조할 수 있도록 함
        model.addAttribute("user", user);
        
        // "index" 뷰 이름을 반환함. 이는 뷰 리졸버에 의해 실제 렌더링될 페이지로 매핑됨 (예: index.html)
        return "index";
    }

    // HTTP POST 요청이 "/submit" 경로로 들어오면 이 메서드가 호출됨
    @PostMapping("/submit")
    public String submitForm(@Valid User user, BindingResult bindingResult, Model model) {
        // @Valid 애노테이션은 User 객체의 유효성을 검사함
        // 유효성 검사 결과가 BindingResult 객체에 저장됨
        if (bindingResult.hasErrors()) {
           
            // 모델에 에러가 있는 User 객체를 다시 추가하여, 에러 메시지를 포함한 폼을 재렌더링함
            model.addAttribute("user", user);
            
            // 유효성 검사를 통과하지 못했으므로 다시 "index" 뷰를 반환하여, 사용자가 폼을 수정할 수 있도록 함
            return "index";
        }
        
            
        // 모델에 User 객체를 추가하여 뷰에서 사용할 수 있도록 함
        model.addAttribute("user", user);
        
        // "result" 뷰 이름을 반환함. 이는 유효한 폼 데이터가 성공적으로 처리되었음을 표시하는 결과 페이지로 매핑됨 (예: result.html)
        return "result";
    }
}