package ktc.secure.coding.config.error;

import java.net.URI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import ktc.secure.coding.config.error.exception.BusinessBaseException;
import ktc.secure.coding.config.error.exception.NotFoundException;

//@ControllerAdvice 애노테이션은 이 클래스가 전역 예외 처리 클래스임을 나타냅니다.
//이 클래스는 애플리케이션의 모든 컨트롤러에서 발생하는 예외를 처리하고 일관된 응답을 생성합니다.
@ControllerAdvice
public class GlobalExceptionHandler {

 // Logger 객체는 예외가 발생할 때 예외 정보를 로그로 기록하는 데 사용됩니다.
 private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

 // HttpRequestMethodNotSupportedException 예외를 처리하는 메서드입니다.
 // 이 예외는 지원되지 않는 HTTP 메서드(예: GET, POST 등)를 호출할 때 발생합니다.
 @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
 protected ResponseEntity<ProblemDetail> handle(HttpRequestMethodNotSupportedException e) {
     // 예외 메시지를 로그에 기록합니다.
     log.error("HttpRequestMethodNotSupportedException", e);
     // 에러 응답을 생성하여 반환합니다.
     return createProblemDetailResponseEntity(ErrorCode.METHOD_NOT_ALLOWED_ERROR);
 }

 // MethodArgumentNotValidException 예외를 처리하는 메서드입니다.
 // 이 예외는 메서드의 파라미터 유효성 검사에서 실패할 때 발생합니다.
 @ExceptionHandler(MethodArgumentNotValidException.class)
 protected ResponseEntity<ProblemDetail> handle(MethodArgumentNotValidException e) {
     // 예외 메시지를 로그에 기록합니다.
     log.error("MethodArgumentNotValidException", e);
     // 에러 응답을 생성하여 반환합니다.
     return createProblemDetailResponseEntity(ErrorCode.INVALID_TYPE_VALUE);
 }

 // BusinessBaseException 예외를 처리하는 메서드입니다.
 // 이 예외는 비즈니스 로직에서 발생할 수 있는 사용자 정의 예외입니다.
 @ExceptionHandler(BusinessBaseException.class)
 protected ResponseEntity<ProblemDetail> handle(BusinessBaseException e) {
     // 예외 메시지를 로그에 기록합니다.
     log.error("BusinessException", e);
     // BusinessBaseException에서 제공하는 ProblemDetail 객체를 그대로 반환합니다.
     return ResponseEntity.status(HttpStatus.valueOf(e.getProblemDetail().getStatus())).body(e.getProblemDetail());
 }

 // NotFoundException 예외를 처리하는 메서드입니다.
 // 이 예외는 주로 요청된 리소스를 찾을 수 없을 때 발생합니다.
 @ExceptionHandler(NotFoundException.class)
 protected ResponseEntity<ProblemDetail> handle(NotFoundException e) {
     // 예외 메시지를 로그에 기록합니다.
     log.error("NotFoundException", e);
     // NotFoundException에서 제공하는 ProblemDetail 객체를 그대로 반환합니다.
     return ResponseEntity.status(HttpStatus.valueOf(e.getProblemDetail().getStatus())).body(e.getProblemDetail());
 }

 // 모든 일반적인 예외를 처리하는 메서드입니다.
 // 위에서 정의된 특정 예외들로 처리되지 않는 모든 예외를 처리합니다.
 @ExceptionHandler(Exception.class)
 protected ResponseEntity<ProblemDetail> handle(Exception e) {
     // 예외 메시지를 로그에 기록합니다.
     log.error("Exception", e);
     // 에러 응답을 생성하여 반환합니다.
     return createProblemDetailResponseEntity(ErrorCode.INTERNAL_SERVER_ERROR);
 }

 // ErrorCode를 기반으로 ProblemDetail 객체를 생성하고, ResponseEntity에 담아 반환하는 헬퍼 메서드입니다.
 private ResponseEntity<ProblemDetail> createProblemDetailResponseEntity(ErrorCode errorCode) {
     // 주어진 에러 코드에 해당하는 상태와 메시지를 기반으로 ProblemDetail 객체를 생성합니다.
     ProblemDetail problemDetail = ProblemDetail.forStatusAndDetail(HttpStatus.valueOf(errorCode.getStatus()), errorCode.getMessage());
     
     // ProblemDetail 객체의 type 필드에 에러 코드에 기반한 URI를 설정합니다.
     problemDetail.setType(URI.create("/errors/" + errorCode.getCode()));
     
     // ProblemDetail 객체의 title 필드에 에러 코드의 이름을 설정합니다.
     problemDetail.setTitle(errorCode.name());
     
     // ProblemDetail 객체의 추가 속성으로 에러 코드를 설정합니다.
     problemDetail.setProperty("code", errorCode.getCode());

     // 생성된 ProblemDetail 객체를 포함한 ResponseEntity를 반환합니다.
     return ResponseEntity.status(HttpStatus.valueOf(errorCode.getStatus())).body(problemDetail);
 }
}
