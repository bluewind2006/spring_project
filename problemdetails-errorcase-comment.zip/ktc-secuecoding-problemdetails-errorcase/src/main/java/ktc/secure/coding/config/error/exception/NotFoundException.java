package ktc.secure.coding.config.error.exception;

import java.net.URI;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;

import ktc.secure.coding.config.error.ErrorCode;

//NotFoundException 클래스는 RuntimeException을 상속받은 사용자 정의 예외 클래스입니다.
//이 클래스는 특정 리소스를 찾을 수 없는 경우에 발생하는 예외를 표현합니다.
//ProblemDetail 객체를 포함하여 예외와 관련된 추가 정보를 제공합니다.
public class NotFoundException extends RuntimeException {

 // ProblemDetail 객체는 예외와 관련된 문제의 세부 사항을 담습니다.
 private final ProblemDetail problemDetail;

 // 생성자는 ErrorCode 객체를 받아서 NotFoundException 객체를 생성합니다.
 public NotFoundException(ErrorCode errorCode) {
     // 부모 클래스인 RuntimeException의 생성자를 호출하여 예외 메시지를 설정합니다.
     super(errorCode.getMessage());
     // ErrorCode를 바탕으로 ProblemDetail 객체를 생성합니다.
     this.problemDetail = createProblemDetail(errorCode);
 }

 // 또 다른 생성자는 ErrorCode 객체와 Throwable 객체를 받아서 예외의 원인을 함께 전달할 수 있습니다.
 public NotFoundException(ErrorCode errorCode, Throwable cause) {
     // 부모 클래스인 RuntimeException의 생성자를 호출하여 예외 메시지와 원인(cause)을 설정합니다.
     super(errorCode.getMessage(), cause);
     // ErrorCode를 바탕으로 ProblemDetail 객체를 생성합니다.
     this.problemDetail = createProblemDetail(errorCode);
 }

 // createProblemDetail 메서드는 주어진 ErrorCode 객체를 기반으로 ProblemDetail 객체를 생성합니다.
 private ProblemDetail createProblemDetail(ErrorCode errorCode) {
     // ErrorCode 객체에서 상태 코드와 메시지를 가져와 ProblemDetail 객체를 생성합니다.
     ProblemDetail problemDetail = ProblemDetail.forStatusAndDetail(HttpStatus.valueOf(errorCode.getStatus()), errorCode.getMessage());
     
     // ProblemDetail 객체의 type 필드에 에러 코드에 기반한 URI를 설정합니다.
     problemDetail.setType(URI.create("/errors/" + errorCode.getCode()));
     
     // ProblemDetail 객체의 title 필드에 에러 코드의 이름을 설정합니다.
     problemDetail.setTitle(errorCode.name());
     
     // ProblemDetail 객체의 추가 속성으로 에러 코드를 설정합니다.
     problemDetail.setProperty("code", errorCode.getCode());
     
     // 생성된 ProblemDetail 객체를 반환합니다.
     return problemDetail;
 }

 // getProblemDetail 메서드는 ProblemDetail 객체를 반환합니다.
 public ProblemDetail getProblemDetail() {
     return problemDetail;
 }
}
