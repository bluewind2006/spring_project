package ktc.secure.coding.config.error;

//ErrorResponse 클래스는 Java 16에서 도입된 Record로 정의된 불변 객체입니다.
//Record는 주로 데이터를 저장하기 위한 간결한 클래스를 정의할 때 사용됩니다.
//ErrorResponse는 에러 메시지와 에러 코드를 담는 객체로 사용됩니다.
public record ErrorResponse(String message, String code) {

 // 주어진 ErrorCode 객체를 기반으로 ErrorResponse 객체를 생성하는 정적 팩토리 메서드입니다.
 // 이 메서드는 ErrorCode 객체의 메시지와 코드를 사용하여 새로운 ErrorResponse 객체를 반환합니다.
 public static ErrorResponse of(final ErrorCode code) {
     // ErrorCode 객체에서 메시지와 코드를 가져와 ErrorResponse 객체를 생성합니다.
     return new ErrorResponse(code.getMessage(), code.getCode());
 }

 // 주어진 ErrorCode 객체와 사용자 정의 메시지를 기반으로 ErrorResponse 객체를 생성하는 정적 팩토리 메서드입니다.
 // 이 메서드는 사용자 정의 메시지와 ErrorCode 객체의 코드를 사용하여 새로운 ErrorResponse 객체를 반환합니다.
 public static ErrorResponse of(final ErrorCode code, final String message) {
     // 사용자 정의 메시지와 ErrorCode 객체의 코드를 사용하여 ErrorResponse 객체를 생성합니다.
     return new ErrorResponse(message, code.getCode());
 }
}
