package ktc.secure.coding.config.error;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import ktc.secure.coding.config.error.exception.BusinessBaseException;

//@ControllerAdvice 애노테이션은 이 클래스가 모든 컨트롤러에서 발생하는 예외를 처리할 수 있도록 해줍니다.
//즉, 이 클래스는 전역 예외 처리기를 제공하며, Spring MVC에서 발생하는 예외들을 잡아 적절하게 처리합니다.
@ControllerAdvice
public class GlobalExceptionHandler {

 // Logger 객체를 사용하여 로그를 기록합니다.
 // 이 로거는 예외가 발생할 때 예외 정보를 로그로 남기기 위해 사용됩니다.
 private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

 // HttpRequestMethodNotSupportedException 예외를 처리하는 메서드입니다.
 // 예외가 발생하면 해당 예외를 로그로 기록하고, 적절한 에러 응답을 생성하여 클라이언트에게 반환합니다.
 @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
 protected ResponseEntity<ErrorResponse> handle(HttpRequestMethodNotSupportedException e) {
     // 예외 메시지를 로그에 기록합니다.
     log.error("HttpRequestMethodNotSupportedException", e);
     // METHOD_NOT_ALLOWED_ERROR 코드와 함께 에러 응답을 생성하여 반환합니다.
     return createErrorResponseEntity(ErrorCode.METHOD_NOT_ALLOWED_ERROR);
 }

 // MethodArgumentNotValidException 예외를 처리하는 메서드입니다.
 // 이 예외는 주로 메서드의 파라미터가 유효하지 않을 때 발생합니다.
 @ExceptionHandler(MethodArgumentNotValidException.class)
 protected ResponseEntity<ErrorResponse> handle(MethodArgumentNotValidException e) {
     // 예외 메시지를 로그에 기록합니다.
     log.error("MethodArgumentNotValidException", e);
     // INVALID_TYPE_VALUE 코드와 함께 에러 응답을 생성하여 반환합니다.
     return createErrorResponseEntity(ErrorCode.INVALID_TYPE_VALUE);
 }

 // BusinessBaseException 예외를 처리하는 메서드입니다.
 // 이 예외는 비즈니스 로직에서 발생할 수 있는 사용자 정의 예외를 처리합니다.
 @ExceptionHandler(BusinessBaseException.class)
 protected ResponseEntity<ErrorResponse> handle(BusinessBaseException e) {
     // 예외 메시지를 로그에 기록합니다.
     log.error("BusinessException", e);
     // 예외 객체에 포함된 ErrorCode를 사용하여 에러 응답을 생성하고 반환합니다.
     return createErrorResponseEntity(e.getErrorCode());
 }

 // 그 외 모든 예외를 처리하는 메서드입니다.
 // 위의 특정 예외들로 처리되지 않는 모든 예외는 이 메서드에서 처리됩니다.
 @ExceptionHandler(Exception.class)
 protected ResponseEntity<ErrorResponse> handle(Exception e) {
     // 예외 메시지를 로그에 기록합니다.
     log.error("Exception", e);
     // INTERNAL_SERVER_ERROR 코드와 함께 에러 응답을 생성하여 반환합니다.
     return createErrorResponseEntity(ErrorCode.INTERNAL_SERVER_ERROR);
 }

 // ErrorCode를 기반으로 ErrorResponse 객체를 생성하고, 해당 객체를 포함하는 ResponseEntity를 반환하는 헬퍼 메서드입니다.
 private ResponseEntity<ErrorResponse> createErrorResponseEntity(ErrorCode errorCode) {
     // ErrorResponse 객체를 생성하여 ResponseEntity에 담아 반환합니다.
     return new ResponseEntity<>(
             ErrorResponse.of(errorCode),             // ErrorResponse 객체 생성
             HttpStatus.valueOf(errorCode.getStatus()) // ErrorCode에서 정의한 HTTP 상태 코드
     );
 }
}
