package ktc.secure.coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtcSecuecodingGlobalexceptionErrorcaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtcSecuecodingGlobalexceptionErrorcaseApplication.class, args);
	}

}
