package ktc.secure.coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtcSecuecodingXqueryXxeSecurityCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtcSecuecodingXqueryXxeSecurityCaseApplication.class, args);
	}

}
