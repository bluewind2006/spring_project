package ktc.secure.coding.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;
import net.sf.saxon.s9api.Processor;
import net.sf.saxon.s9api.DocumentBuilder;
import net.sf.saxon.lib.FeatureKeys;

@Configuration
public class XmlConfig {

    // DocumentBuilderFactory Bean 설정 메서드.
    // XML 파서를 생성하기 위한 DocumentBuilderFactory를 설정하고 반환합니다.
    @Bean
    public DocumentBuilderFactory documentBuilderFactory() throws ParserConfigurationException, SAXException {
        // 새로운 DocumentBuilderFactory 인스턴스를 생성.
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        
        // XML 외부 개체 삽입 방지: Doctype 선언을 비활성화하여 XXE(External Entity Injection) 공격을 방지.
        dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        
        // 외부 일반 개체 엔티티 비활성화: 외부 엔티티의 사용을 막아 추가적인 XXE 공격을 방지.
        dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
        
        // 외부 파라미터 엔티티 비활성화: 외부 파라미터 엔티티의 사용을 막아 추가적인 XXE 공격을 방지.
        dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        
        // 외부 DTD(Document Type Definition) 로드를 비활성화하여 XXE 공격을 방지.
        dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        
        // XInclude 기능 비활성화: XML 문서의 다른 부분을 포함시키는 기능을 막아 보안 강화.
        dbf.setXIncludeAware(false);
        
        // 엔티티 참조 확장을 비활성화하여 XXE 공격을 방지.
        dbf.setExpandEntityReferences(false);
        
        // 구성된 DocumentBuilderFactory 객체를 반환.
        return dbf;
    }

    // XPathFactory Bean 설정 메서드.
    // XPath 표현식 처리를 위한 XPathFactory를 설정하고 반환합니다.
    @Bean
    public XPathFactory xPathFactory() {
        try {
            // 새로운 XPathFactory 인스턴스를 생성.
            XPathFactory xPathFactory = XPathFactory.newInstance();
            
            // 보안 프로세싱 기능 활성화: XPath 표현식 평가 시 보안 기능을 강화하여 공격 방지.
            xPathFactory.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);
            
            // 구성된 XPathFactory 객체를 반환.
            return xPathFactory;
        } catch (XPathFactoryConfigurationException e) {
            // XPathFactory 설정 중 오류가 발생하면 런타임 예외를 발생시킴.
            throw new RuntimeException("Error configuring XPathFactory", e);
        }
    }

    // Saxon Processor Bean 설정 메서드.
    // XSLT 프로세싱을 위한 Saxon Processor를 설정하고 반환합니다.
    @Bean
    public Processor saxonProcessor() {
        // Saxon Processor 인스턴스를 생성. XSLT 2.0 이상의 기능을 지원.
        Processor processor = new Processor(false);
        
        // 외부 함수 호출 비활성화: 외부 함수를 호출하지 않도록 설정하여 XSLT 처리 시 보안을 강화.
        processor.getUnderlyingConfiguration().setBooleanProperty(FeatureKeys.ALLOW_EXTERNAL_FUNCTIONS, false);
        
        // 구성된 Saxon Processor 객체를 반환.
        return processor;
    }
}
