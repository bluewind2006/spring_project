package ktc.secure.coding.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import net.sf.saxon.s9api.*;

import javax.xml.transform.stream.StreamSource;

@Service
public class XmlService {

    private final DocumentBuilderFactory documentBuilderFactory;
    private final XPathFactory xPathFactory;
    private final Processor saxonProcessor;

    @Autowired
    public XmlService(DocumentBuilderFactory documentBuilderFactory, XPathFactory xPathFactory, Processor saxonProcessor) {
        this.documentBuilderFactory = documentBuilderFactory;
        this.xPathFactory = xPathFactory;
        this.saxonProcessor = saxonProcessor;
    }

    public String evaluateXPath(String xml, String expression) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        DocumentBuilder builder = documentBuilderFactory.newDocumentBuilder();
        Document document = builder.parse(new InputSource(new StringReader(xml)));

        XPath xPath = xPathFactory.newXPath();
        return xPath.evaluate(expression, document);
    }

    public String evaluateXQuery(String xml, String expression, String parameter) throws SaxonApiException {
        net.sf.saxon.s9api.DocumentBuilder saxonBuilder = saxonProcessor.newDocumentBuilder();
        XdmNode document = saxonBuilder.build(new StreamSource(new StringReader(xml)));

        XQueryCompiler compiler = saxonProcessor.newXQueryCompiler();
        XQueryExecutable executable = compiler.compile(expression);
        XQueryEvaluator evaluator = executable.load();

        evaluator.setContextItem(document);
        evaluator.setExternalVariable(new QName("param"), new XdmAtomicValue(parameter));

        XdmValue result = evaluator.evaluate();
        return result.toString();
    }
}