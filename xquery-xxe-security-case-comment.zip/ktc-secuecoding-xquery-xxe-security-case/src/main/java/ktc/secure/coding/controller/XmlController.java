package ktc.secure.coding.controller;

import ktc.secure.coding.service.XmlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class XmlController {

    @Autowired
    private XmlService xmlService;

    @PostMapping("/test-xxe")
    public String testXXE(@RequestBody String xml) {
        try {
            return xmlService.evaluateXPath(xml, "/foo");
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    @PostMapping("/test-xpath")
    public String testXPath(@RequestBody String xml) {
        try {
            return xmlService.evaluateXPath(xml, "//user[username/text() = 'admin' or '1'='1']/username/text()");
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    @PostMapping("/test-xquery")
    public String testXQuery(@RequestBody String xml) {
        try {
            return xmlService.evaluateXQuery(xml, "for $x in /users/user[username/text()=$param] return $x", "admin' or '1'='1");
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}