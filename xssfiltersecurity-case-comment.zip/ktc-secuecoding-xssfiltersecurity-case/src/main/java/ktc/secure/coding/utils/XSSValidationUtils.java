package ktc.secure.coding.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Base64;
import java.util.Map;
import java.util.regex.Pattern;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class XSSValidationUtils {

    // XSS 공격을 탐지하기 위한 정규 표현식 패턴들.
    private static final Pattern scriptPattern = Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE);
    private static final Pattern srcPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
    private static final Pattern evalPattern = Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);

    // 이모지와 같은 특수 문자를 탐지하기 위한 정규 표현식 패턴.
    private static final Pattern emojiPattern = Pattern.compile("[\\p{So}\\p{Cn}]", Pattern.UNICODE_CHARACTER_CLASS);

    // URL 세그먼트가 유효한지 확인하기 위한 정규 표현식 패턴.
    private static final Pattern urlSegmentPattern = Pattern.compile("^[a-zA-Z0-9-_.~%]+$");

    // 주어진 URL이 유효한지 검증하는 메서드.
    public static boolean isValidURL(String url) {
        String[] segments = url.split("/");  // URL을 '/'로 분할하여 각 세그먼트를 검사.
        for (String segment : segments) {
            if (!urlSegmentPattern.matcher(segment).matches()) {  // 각 세그먼트가 유효한지 정규 표현식을 통해 확인.
                return false;
            }
        }
        return true;  // 모든 세그먼트가 유효하면 true 반환.
    }

    // 요청 파라미터가 유효한지 검증하는 메서드.
    public static boolean isValidRequestParam(String param) {
        String[] paramSegments = param.split("&");  // 파라미터를 '&'로 분할하여 각 세그먼트를 검사.
        for (String segment : paramSegments) {
            if (!isSafeString(segment)) {  // 각 세그먼트가 안전한지 확인.
                return false;
            }
        }
        return true;  // 모든 세그먼트가 안전하면 true 반환.
    }

    // JSON 형식의 URL 패턴이 유효한지 검증하는 메서드.
    public static boolean isValidURLPattern(String input) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> map = mapper.readValue(input, Map.class);  // JSON 문자열을 Map으로 변환.
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                // Map의 키와 값이 안전한지 확인.
                if (!isSafeString(entry.getKey()) || !isSafeString(entry.getValue().toString())) {
                    return false;
                }
            }
        } catch (JsonProcessingException e) {
            return false;  // JSON 처리 중 오류가 발생하면 false 반환.
        }
        return true;  // 모든 키와 값이 안전하면 true 반환.
    }

    // 입력 문자열이 안전한지 검증하는 메서드.
    public static boolean isSafeString(String input) {
        if (input == null || input.isEmpty()) {
            return true;  // 입력이 null이거나 비어있으면 안전하다고 판단.
        }

        if (containsXSS(input)) {  // 입력에 XSS 공격 패턴이 포함되어 있는지 확인.
            return false;
        }

        try {
            if (isBase64Encoded(input)) {  // 입력이 Base64로 인코딩된 문자열인지 확인.
                String decodedBase64 = new String(Base64.getDecoder().decode(input));
                if (containsXSS(decodedBase64)) {  // Base64로 디코딩한 결과에 XSS 패턴이 있는지 확인.
                    return false;
                }
            }
        } catch (IllegalArgumentException ignored) {
            // Base64로 디코딩할 수 없는 경우, 이 예외는 무시됨.
        	//필요하면 로그 처리
        	//Logger.getLogger(RequestWrapper.class.getName()).log(Level.WARNING, "Invalid Base64 encoding: " + input, e);
        }

        try {
            if (isURLEncoded(input)) {  // 입력이 URL 인코딩된 문자열인지 확인.
                String decodedURL = URLDecoder.decode(input, "UTF-8");
                if (containsXSS(decodedURL)) {  // URL로 디코딩한 결과에 XSS 패턴이 있는지 확인.
                    return false;
                }
            }
        } catch (UnsupportedEncodingException ignored) {
            // URL 디코딩 중 발생할 수 있는 예외를 무시함.
        	//필요하면 로그 처리
        	//Logger.getLogger(RequestWrapper.class.getName()).log(Level.WARNING, "Unsupported Encoding: " + input, e);
        }

        return true;  // 위의 검사에서 모두 통과하면 입력은 안전하다고 판단.
    }

    // 입력 문자열에 XSS 패턴이 포함되어 있는지 확인하는 메서드.
    private static boolean containsXSS(String input) {
        return scriptPattern.matcher(input).find()  // <script> 태그를 포함하는지 확인.
                || srcPattern.matcher(input).find()  // src 속성에 악성 스크립트가 포함되어 있는지 확인.
                || evalPattern.matcher(input).find();  // eval() 함수 호출을 포함하는지 확인.
    }

    // 입력 문자열이 Base64로 인코딩된 문자열인지 확인하는 메서드.
    private static boolean isBase64Encoded(String input) {
        return input.matches("^[A-Za-z0-9+/=]+$");  // Base64 인코딩 패턴에 맞는지 확인.
    }

    // 입력 문자열이 URL 인코딩된 문자열인지 확인하는 메서드.
    private static boolean isURLEncoded(String input) {
        try {
            // 입력 문자열을 URL 디코딩한 후, 다시 URL 인코딩한 결과가 원래 문자열과 같은지 확인.
            String encoded = URLEncoder.encode(URLDecoder.decode(input, "UTF-8"), "UTF-8");
            return input.equals(encoded);
        } catch (UnsupportedEncodingException | IllegalArgumentException e) {
            return false;  // URL 인코딩이나 디코딩 중 오류가 발생하면 false 반환.
        }
    }
}
