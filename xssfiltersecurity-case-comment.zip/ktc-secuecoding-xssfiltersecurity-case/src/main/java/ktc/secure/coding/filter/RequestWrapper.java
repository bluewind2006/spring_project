package ktc.secure.coding.filter;


import ktc.secure.coding.exception.XSSServletException;
import ktc.secure.coding.utils.XSSValidationUtils;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import java.io.BufferedReader;
import java.io.IOException;

public class RequestWrapper extends HttpServletRequestWrapper {

    // 생성자에서 원본 HttpServletRequest를 감싸서 RequestWrapper 객체를 생성.
    public RequestWrapper(HttpServletRequest request) {
        super(request); // 부모 클래스인 HttpServletRequestWrapper의 생성자를 호출하여 원본 요청을 저장.
    }

    // 특정 파라미터 값을 가져오는 메서드. 원본 요청의 getParameter 메서드를 오버라이드.
    @Override
    public String getParameter(String name) {
        // 원본 요청에서 파라미터 값을 가져옴.
        String value = super.getParameter(name);

        // 파라미터 값이 XSS 공격에 안전한지 검증.
        if (!XSSValidationUtils.isValidRequestParam(value)) {
            // 안전하지 않은 값이 발견되면 XSSServletException 예외를 발생시킴.
            throw new XSSServletException("Invalid parameter value");
        }

        // 검증을 통과한 경우 원본 값을 반환.
        return value;
    }

    // 특정 파라미터의 여러 값을 가져오는 메서드. 원본 요청의 getParameterValues 메서드를 오버라이드.
    @Override
    public String[] getParameterValues(String name) {
        // 원본 요청에서 파라미터 값 배열을 가져옴.
        String[] values = super.getParameterValues(name);

        // 배열의 각 값이 XSS 공격에 안전한지 검증.
        for (String value : values) {
            if (!XSSValidationUtils.isValidRequestParam(value)) {
                // 안전하지 않은 값이 발견되면 XSSServletException 예외를 발생시킴.
                throw new XSSServletException("Invalid parameter value");
            }
        }

        // 모든 값이 검증을 통과한 경우 원본 배열을 반환.
        return values;
    }

    // 요청 본문을 읽어오는 메서드. 원본 요청의 getReader 메서드를 오버라이드.
    @Override
    public BufferedReader getReader() throws IOException {
        // 원본 요청의 BufferedReader를 가져옴.
        BufferedReader reader = super.getReader();
        
        // 입력된 데이터를 저장할 StringBuilder 객체를 생성.
        StringBuilder inputBuffer = new StringBuilder();
        String line;

        // 요청 본문을 한 줄씩 읽어서 StringBuilder에 저장.
        while ((line = reader.readLine()) != null) {
            inputBuffer.append(line);
        }

        // 모든 줄을 읽어서 하나의 문자열로 결합.
        String input = inputBuffer.toString();

        // 요청 본문이 XSS 공격에 안전한지 검증.
        if (!XSSValidationUtils.isValidURLPattern(input)) {
            // 안전하지 않은 본문이 발견되면 XSSServletException 예외를 발생시킴.
            throw new XSSServletException("Invalid request body");
        }

        // 검증을 통과한 본문을 사용하여 새로운 BufferedReader를 생성하여 반환.
        return new BufferedReader(new java.io.StringReader(input));
    }
}
