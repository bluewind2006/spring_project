package ktc.secure.coding.exception;

public class XSSServletException extends RuntimeException {
    public XSSServletException(String message) {
        super(message);
    }
}