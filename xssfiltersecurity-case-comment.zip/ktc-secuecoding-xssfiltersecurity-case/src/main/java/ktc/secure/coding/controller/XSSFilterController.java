package ktc.secure.coding.controller;

import ktc.secure.coding.exception.XSSServletException;
import ktc.secure.coding.utils.XSSValidationUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Controller
public class XSSFilterController {

    @Autowired
    private ObjectMapper objectMapper;

    @GetMapping("/form")
    public String showForm() {
        return "form";
    }

    @PostMapping("/submit")
    public String submitForm(@RequestParam(name = "input") String input, Model model) {
        if (!XSSValidationUtils.isSafeString(input)) {
            throw new XSSServletException("Invalid parameter value");
        }
        model.addAttribute("input", input);
        return "result";
    }

    @PostMapping("/submitJson")
    public ResponseEntity<String> submitJson(@RequestBody Map<String, Object> jsonInput) {
        for (Map.Entry<String, Object> entry : jsonInput.entrySet()) {
            if (!XSSValidationUtils.isSafeString(entry.getKey()) || !XSSValidationUtils.isSafeString(entry.getValue().toString())) {
                throw new XSSServletException("Invalid JSON input");
            }
        }
        try {
            String jsonResponse = objectMapper.writeValueAsString(jsonInput);
            return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Invalid JSON input", HttpStatus.BAD_REQUEST);
        }
    }
}