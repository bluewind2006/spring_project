package ktc.secure.coding.model;


public record ErrorResponse(String message, int status) {
}