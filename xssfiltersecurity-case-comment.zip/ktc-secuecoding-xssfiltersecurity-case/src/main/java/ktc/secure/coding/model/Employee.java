package ktc.secure.coding.model;


public record Employee(String name, String position, Address address) {
}