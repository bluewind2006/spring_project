package ktc.secure.coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtcSecuecodingXssfiltersecurityCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtcSecuecodingXssfiltersecurityCaseApplication.class, args);
	}

}
