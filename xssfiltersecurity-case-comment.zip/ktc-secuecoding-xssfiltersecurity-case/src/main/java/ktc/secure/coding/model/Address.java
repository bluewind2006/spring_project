package ktc.secure.coding.model;


public record Address(String street, String city, String zipCode) {
}