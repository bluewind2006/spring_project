package ktc.secure.coding.filter;


import ktc.secure.coding.exception.XSSServletException;
import ktc.secure.coding.utils.XSSValidationUtils;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.logging.Logger;

public class ResponseFilter implements Filter {

    // 로깅을 위한 Logger 객체를 생성. 이 필터 클래스의 로그를 기록할 때 사용됨.
    private static final Logger logger = Logger.getLogger(ResponseFilter.class.getName());

    // 필터 초기화 메서드. 필터가 생성될 때 한 번 호출됨.
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        logger.info("ResponseFilter initialized"); // 필터가 초기화되었음을 로그로 기록.
    }

    // 필터의 핵심 메서드. 요청을 처리하기 전에 실행되며, 요청과 응답을 필터링할 수 있음.
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        // 요청 객체를 HttpServletRequest로 캐스팅.
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        
        // 요청 URI를 가져옴.
        String requestURI = httpRequest.getRequestURI();

        // 요청 URI가 XSS(크로스 사이트 스크립팅) 공격에 안전한지 검사.
        if (!XSSValidationUtils.isValidURL(requestURI)) {
            // URI가 유효하지 않으면 XSSServletException 예외를 발생시킴.
            throw new XSSServletException("Invalid request URL");
        }

        // RequestWrapper 객체를 사용하여 원본 요청을 감쌈.
        // RequestWrapper는 요청 데이터를 변경하거나 가로채기 위해 사용됨.
        RequestWrapper requestWrapper = new RequestWrapper(httpRequest);
        
        // 다음 필터나 서블릿으로 요청과 응답을 전달.
        chain.doFilter(requestWrapper, response);
    }

    // 필터가 소멸될 때 호출되는 메서드. 필터가 제거될 때 한 번 호출됨.
    @Override
    public void destroy() {
        logger.info("ResponseFilter destroyed"); // 필터가 소멸되었음을 로그로 기록.
        // 정리 작업을 수행할 수 있음 (필요한 자원 정리 코드가 여기 들어갈 수 있음).
    }
}
