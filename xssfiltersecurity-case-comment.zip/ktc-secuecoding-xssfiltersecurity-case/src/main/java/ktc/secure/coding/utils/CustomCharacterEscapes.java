package ktc.secure.coding.utils;

import com.fasterxml.jackson.core.SerializableString;
import com.fasterxml.jackson.core.io.CharacterEscapes;
import com.fasterxml.jackson.core.io.SerializedString;

public class CustomCharacterEscapes extends CharacterEscapes {

    private final int[] asciiEscapes;

    public CustomCharacterEscapes() {
        asciiEscapes = CharacterEscapes.standardAsciiEscapesForJSON();
        asciiEscapes['<'] = CharacterEscapes.ESCAPE_STANDARD;
        asciiEscapes['>'] = CharacterEscapes.ESCAPE_STANDARD;
        asciiEscapes['&'] = CharacterEscapes.ESCAPE_STANDARD;
        asciiEscapes['\''] = CharacterEscapes.ESCAPE_STANDARD;
        asciiEscapes['"'] = CharacterEscapes.ESCAPE_STANDARD;
        asciiEscapes['/'] = CharacterEscapes.ESCAPE_STANDARD;
    }

    @Override
    public int[] getEscapeCodesForAscii() {
        return asciiEscapes;
    }

    @Override
    public SerializableString getEscapeSequence(int ch) {
        switch (ch) {
            case '<':
                return new SerializedString("\\u003C");
            case '>':
                return new SerializedString("\\u003E");
            case '&':
                return new SerializedString("\\u0026");
            case '\'':
                return new SerializedString("\\u0027");
            case '"':
                return new SerializedString("\\u0022");
            case '/':
                return new SerializedString("\\u002F");
            default:
                return new SerializedString(String.format("\\u%04x", ch));
        }
    }
}