package ktc.secure.coding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KtcSecuecodingFileupdownCase2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
