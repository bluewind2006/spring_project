package ktc.secure.coding.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.constraints.NotNull;
import ktc.secure.coding.exception.FileExtensionNotAllowedException;
import ktc.secure.coding.exception.FileSizeExceededException;
import ktc.secure.coding.exception.FileUploadException;

@Controller
@Validated
public class FileUploadController {

    // 파일이 저장될 경로, 허용된 파일 확장자, 최대 파일 크기, 다운로드 가능한 확장자 등을 설정 파일에서 주입받음.
    @Value("${fileStorePath}")
    private String fileStorePath;

    @Value("${fileUpload.Extensions.General}")
    private String[] allowedExtensions;

    @Value("${fileUpload.maxSize}")
    private long maxSize;

    @Value("${fileDownload.Extensions}")
    private String[] downloadExtensions;

    // 파일의 MIME 타입을 확인하기 위해 Apache Tika 라이브러리를 사용.
    private final Tika tika = new Tika();

    // 안전한 랜덤 파일 이름을 생성하기 위해 SecureRandom을 사용.
    private final SecureRandom random = new SecureRandom();

    // 파일 이름의 유효성을 검증하기 위한 정규식 패턴.
    private static final Pattern FILENAME_PATTERN = Pattern.compile("^[a-zA-Z0-9._\\- ]+$");

    // 윈도우에서 사용 불가능한 예약된 파일 이름 목록을 저장.
    private static final Set<String> INVALID_FILENAMES = Set.of(
        "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
    );

    // 업로드된 파일의 해시값을 저장하는 맵. 키는 파일 이름, 값은 해시값.
    private final Map<String, String> fileHashes = new HashMap<>();

    // 기본 페이지를 렌더링할 때 호출되는 메서드로, 업로드된 파일 목록을 모델에 추가함.
    @GetMapping("/")
    public String index(Model model) {
        List<String> files = listUploadedFiles(); // 업로드된 파일 목록을 가져옴.
        model.addAttribute("files", files); // 파일 목록을 모델에 추가.
        model.addAttribute("fileHashes", fileHashes); // 파일 해시값도 모델에 추가.
        return "index"; // index.html 뷰를 반환.
    }

    // 파일 업로드를 처리하는 메서드. 업로드된 파일을 검증하고 서버에 저장.
    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") @NotNull MultipartFile file,
                                   RedirectAttributes redirectAttributes) throws IOException {

        try {
            // 원본 파일 이름을 가져옴.
            String originalFilename = file.getOriginalFilename();
            if (originalFilename == null) {
                throw new FileUploadException("파일 이름이 유효하지 않습니다."); // 파일 이름이 없으면 예외 발생.
            }

            // 파일 이름을 안전하게 변환(유효하지 않은 문자를 '_'로 대체).
            String sanitizedFilename = sanitizeFilename(originalFilename);
            
            // 확장자와 파일 이름을 분리하여 저장.
            String extension = "." + FilenameUtils.getExtension(sanitizedFilename).toLowerCase();
            String baseName = FilenameUtils.getBaseName(sanitizedFilename);

            // 파일 확장자가 허용된 확장자인지 검증.
            if (!Arrays.asList(allowedExtensions).contains(extension)) {
                throw new FileExtensionNotAllowedException("등록 불가능한 확장자입니다."); // 허용되지 않은 확장자면 예외 발생.
            }

            // 파일 이름이 유효한지 검증.
            if (!isValidFilename(baseName)) {
                throw new FileUploadException("파일 이름이 유효하지 않습니다."); // 유효하지 않은 파일 이름이면 예외 발생.
            }

            // 파일 크기가 설정된 최대 크기를 초과하지 않는지 검증.
            if (file.getSize() > maxSize) {
                throw new FileSizeExceededException("파일 크기가 제한을 초과했습니다."); // 파일 크기가 너무 크면 예외 발생.
            }

            // 파일 이름에 Null 바이트가 포함되었는지, 파일 경로가 유효한지 검증.
            if (containsNullByte(sanitizedFilename) || containsInvalidPath(sanitizedFilename)) {
                throw new FileUploadException("파일 이름이 잘못되었습니다."); // 잘못된 파일 이름이면 예외 발생.
            }

            // 파일의 MIME 타입이 올바른지 검증.
            if (!isValidMimeType(file, extension)) {
                throw new FileUploadException("파일 콘텐츠 유형이 잘못되었습니다."); // MIME 타입이 잘못되었으면 예외 발생.
            }

            // 잠재적으로 위험한 콘텐츠가 포함되어 있는지 검증.
            if (hasPotentiallyDangerousContent(file, extension)) {
                throw new FileUploadException("파일에 잠재적으로 위험한 콘텐츠가 포함되어 있습니다."); // 위험한 콘텐츠가 포함된 경우 예외 발생.
            }

            // 랜덤한 파일 이름을 생성하고 파일 저장 경로를 설정.
            String randomFileName;
            Path destinationPath;
            do {
                randomFileName = generateRandomFileName(extension); // 랜덤한 파일 이름 생성.
                destinationPath = getSafeFilePath(randomFileName); // 저장 경로 생성.
            } while (Files.exists(destinationPath)); // 동일한 이름의 파일이 존재하지 않을 때까지 반복.

            // 업로드 경로가 존재하지 않으면 디렉토리를 생성.
            if (Files.notExists(destinationPath.getParent())) {
                Files.createDirectories(destinationPath.getParent());
            }

            // 파일을 지정된 경로에 저장.
            Files.copy(file.getInputStream(), destinationPath);

            // 파일 해시값을 계산하고, 해시값을 맵에 저장.
            String fileHash = calculateFileHash(destinationPath);
            fileHashes.put(randomFileName, fileHash);

            // 업로드 성공 메시지를 플래시 속성에 추가.
            redirectAttributes.addFlashAttribute("message", "파일이 성공적으로 업로드되었습니다. 이름: " + randomFileName);
        } catch (IOException e) {
            // 파일 업로드에 실패했을 때 예외를 던짐.
            throw new FileUploadException("파일 업로드에 실패했습니다.", e);
        }

        return "redirect:/"; // 업로드 후 기본 페이지로 리다이렉트.
    }

    // 파일 다운로드를 처리하는 메서드.
    @GetMapping("/download/{filename}")
    public ResponseEntity<byte[]> downloadFile(@PathVariable("filename") String filename) throws IOException {
        // 파일 이름의 유효성 검증.
        if (containsInvalidPath(filename) || containsNullByte(filename)) {
            return ResponseEntity.badRequest().body(null); // 잘못된 파일 경로일 경우 400 에러 반환.
        }

        // 파일 확장자가 다운로드 가능한지 검증.
        String extension = "." + FilenameUtils.getExtension(filename).toLowerCase();
        if (!Arrays.asList(downloadExtensions).contains(extension)) {
            return ResponseEntity.badRequest().body(null); // 허용되지 않은 확장자일 경우 400 에러 반환.
        }

        // 파일 경로를 설정하고, 파일이 존재하는지 확인.
        Path filePath = getSafeFilePath(filename);
        File file = filePath.toFile();
        if (!file.exists() || !file.isFile()) {
            return ResponseEntity.notFound().build(); // 파일이 없을 경우 404 에러 반환.
        }
        
        // 다운로드 시점에 파일의 해시값을 다시 계산.
        String currentFileHash = calculateFileHash(filePath);
        String originalFileHash = fileHashes.get(filename);

        // 파일의 해시값이 변경되었는지 확인하고, 변경되었으면 409 에러 반환.
        if (!currentFileHash.equals(originalFileHash)) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                                 .body(("파일이 손상되었거나 변경되었습니다.").getBytes());
        }
        
        // 파일을 읽어서 바이트 배열로 반환.
        byte[] fileContent;
        try (InputStream fileInputStream = new FileInputStream(file)) {
            fileContent = IOUtils.toByteArray(fileInputStream); // 파일을 바이트 배열로 변환.
        } // try-with-resources로 스트림을 자동으로 닫음.

        // 파일의 MIME 타입을 확인.
        String mimeType = tika.detect(file);

        // HTTP 응답으로 파일 내용을 반환, 해시값은 헤더에 포함.
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(mimeType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + sanitizeHeaderFilename(file.getName()) + "\"")
                .header("X-File-Hash", fileHashes.get(filename)) // 해시값을 헤더에 추가.
                .body(fileContent);
    }

    // 파일 해시를 계산하는 메서드. SHA-256 알고리즘을 사용.
    private String calculateFileHash(Path filePath) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256"); // SHA-256 해시 알고리즘 사용.
            byte[] fileBytes = Files.readAllBytes(filePath); // 파일의 바이트 데이터를 읽어옴.
            byte[] hashBytes = digest.digest(fileBytes); // 해시값 계산.
            return Base64.getEncoder().encodeToString(hashBytes); // 해시값을 Base64로 인코딩하여 반환.
        } catch (NoSuchAlgorithmException e) {
            throw new IOException("해시 계산에 실패했습니다.", e); // 알고리즘을 찾지 못할 경우 예외 발생.
        }
    }
    
    // 업로드된 파일 목록을 가져오는 메서드. 파일 경로에 있는 모든 파일 이름을 리스트로 반환.
    private List<String> listUploadedFiles() {
        File folder = new File(fileStorePath); // 파일이 저장된 경로.
        File[] files = folder.listFiles(); // 경로 내의 모든 파일을 가져옴.
        if (files != null) {
            return Arrays.stream(files)
                    .filter(File::isFile) // 파일만 필터링.
                    .map(File::getName) // 파일 이름을 추출.
                    .collect(Collectors.toList()); // 리스트로 변환하여 반환.
        }
        return Collections.emptyList(); // 파일이 없을 경우 빈 리스트 반환.
    }

    // 랜덤 파일 이름을 생성하는 메서드. UUID와 파일 확장자를 조합.
    private String generateRandomFileName(String extension) {
        return UUID.randomUUID().toString() + extension; // UUID를 사용하여 랜덤 파일 이름 생성.
    }

    // 파일의 MIME 타입이 허용된 유형인지 검증하는 메서드.
    private boolean isValidMimeType(MultipartFile file, String extension) throws IOException {
        String mimeType = tika.detect(file.getInputStream()); // 파일의 MIME 타입을 식별.
        switch (extension) {
            case ".jpg":
            case ".jpeg":
                return mimeType.equals("image/jpeg");
            case ".png":
                return mimeType.equals("image/png");
            case ".gif":
                return mimeType.equals("image/gif");
            case ".pdf":
                return mimeType.equals("application/pdf");
            case ".xls":
            case ".xlsx":
                return mimeType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    || mimeType.equals("application/vnd.ms-excel");
            default:
                return false; // 허용되지 않은 MIME 타입일 경우 false 반환.
        }
    }

    // 파일 이름에 Null 바이트가 포함되어 있는지 확인하는 메서드.
    private boolean containsNullByte(String filename) {
        return filename != null && filename.contains("\0"); // Null 바이트가 포함된 경우 true 반환.
    }

    // 경로가 유효한지 확인하는 메서드. 파일 경로가 지정된 루트 경로 내에 있는지 검증.
    private boolean containsInvalidPath(String filename) {
        Path filePath = Paths.get(fileStorePath).resolve(filename).normalize();
        return !filePath.startsWith(Paths.get(fileStorePath)); // 루트 경로를 벗어나면 true 반환.
    }

    // 파일 이름이 유효한지 검증하는 메서드.
    private boolean isValidFilename(String filename) {
        if (INVALID_FILENAMES.contains(filename.toUpperCase())) {
            return false; // 윈도우에서 예약된 파일 이름이면 false 반환.
        }
        return FILENAME_PATTERN.matcher(filename).matches(); // 정규식 패턴에 맞는지 확인.
    }

    // 안전한 파일 경로를 생성하는 메서드. 파일 이름을 정규화하여 경로를 반환.
    private Path getSafeFilePath(String filename) {
        return Paths.get(fileStorePath).resolve(filename).normalize(); // 파일 경로를 정규화하여 반환.
    }

    // 파일 이름을 정화하는 메서드. 허용되지 않은 문자를 '_'로 대체.
    private String sanitizeFilename(String filename) {
        return filename.replaceAll("[^a-zA-Z0-9._\\- ]", "_"); // 허용되지 않은 문자를 '_'로 대체.
    }

    // 파일 이름을 HTTP 헤더에 사용할 수 있도록 정화하는 메서드. 개행 문자를 제거.
    private String sanitizeHeaderFilename(String filename) {
        return filename.replaceAll("[\\r\\n]", "_"); // 개행 문자를 제거하여 반환.
    }

    // 파일에 잠재적으로 위험한 콘텐츠가 포함되어 있는지 확인하는 메서드.
    private boolean hasPotentiallyDangerousContent(MultipartFile file, String extension) throws IOException {
        try (InputStream inputStream = file.getInputStream();
             Scanner scanner = new Scanner(inputStream, StandardCharsets.UTF_8.name())) {
            String content = scanner.useDelimiter("\\A").next();

            // 확장자별로 특정 보안 검사를 수행.
            if (extension.equals(".gif") && content.contains("shell_exec")) {
                return true; // GIF 파일에 shell_exec이 포함된 경우.
            }

            if ((extension.equals(".svg") || extension.equals(".xml")) && content.contains("DOCTYPE")) {
                return true; // SVG나 XML 파일에 DOCTYPE이 포함된 경우.
            }

            if (extension.equals(".svg") && (content.contains("<script") || content.contains("onload="))) {
                return true; // SVG 파일에 <script>나 onload 속성이 포함된 경우.
            }

            if (content.contains("'sleep(")) {
                return true; // 파일에 'sleep('이 포함된 경우.
            }

            if (extension.equals(".png") && file.getSize() > 1024 * 1024) { // PNG 파일이 1MB를 초과하는 경우.
                return true;
            }

            return false; // 위 조건에 해당하지 않으면 안전한 파일로 간주.
        }
    }
}
