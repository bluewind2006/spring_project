package ktc.secure.coding.exception;


public class FileSizeExceededException extends FileUploadException {
    public FileSizeExceededException(String message) {
        super(message);
    }
}
