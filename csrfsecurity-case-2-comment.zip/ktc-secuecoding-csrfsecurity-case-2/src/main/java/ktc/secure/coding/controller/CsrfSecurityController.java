package ktc.secure.coding.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import ktc.secure.coding.util.CsrfTokenUtil;

@Controller
public class CsrfSecurityController {

    // 홈 페이지 요청을 처리하는 메서드.
    @GetMapping("/home")
    public String home(HttpSession session, Model model) {
        // 새로운 CSRF 토큰을 생성.
        String csrfToken = CsrfTokenUtil.generateToken();
        // 생성된 CSRF 토큰을 세션에 저장.
        CsrfTokenUtil.setTokenInSession(session, csrfToken);
        // 생성된 CSRF 토큰을 모델에 추가하여 뷰에서 사용할 수 있도록 함.
        model.addAttribute("csrfToken", csrfToken);
        // "home" 뷰를 반환.
        return "home";
    }

    // 프로필 업데이트 요청을 처리하는 메서드.
    @PostMapping("/updateProfile")
    public String updateProfile(@RequestParam("name") String name, HttpServletRequest request, Model model) {
        // 요청에서 전송된 CSRF 토큰이 유효한지 검증.
        if (!CsrfTokenUtil.validateToken(request)) {
            // CSRF 토큰이 유효하지 않은 경우, 오류 메시지를 모델에 추가하고 홈 페이지로 돌아감.
            model.addAttribute("message", "CSRF token validation failed");
            return "home";
        }
        // CSRF 토큰이 유효한 경우, 프로필 업데이트 성공 메시지를 모델에 추가하고 홈 페이지로 돌아감.
        model.addAttribute("message", "Profile updated successfully for: " + name);
        return "home";
    }

    // 로그인 페이지 요청을 처리하는 메서드.
    @GetMapping("/login")
    public String login(HttpSession session, Model model) {
        // 새로운 CSRF 토큰을 생성.
        String csrfToken = CsrfTokenUtil.generateToken();
        // 생성된 CSRF 토큰을 세션에 저장.
        CsrfTokenUtil.setTokenInSession(session, csrfToken);
        // 생성된 CSRF 토큰을 모델에 추가하여 뷰에서 사용할 수 있도록 함.
        model.addAttribute("csrfToken", csrfToken);
        // "login" 뷰를 반환.
        return "login";
    }
}
