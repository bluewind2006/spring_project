package ktc.secure.coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtcSecuecodingCsrfsecurityCase2Application {

	public static void main(String[] args) {
		SpringApplication.run(KtcSecuecodingCsrfsecurityCase2Application.class, args);
	}

}
