package ktc.secure.coding.util;

import java.security.SecureRandom;
import java.util.Base64;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

public class CsrfTokenUtil {

    // CSRF 토큰을 세션에 저장할 때 사용할 속성 이름을 상수로 정의.
    private static final String CSRF_TOKEN_ATTRIBUTE = "CSRF_TOKEN";

    // 새로운 CSRF 토큰을 생성하는 메서드.
    public static String generateToken() {
        // 암호학적으로 안전한 랜덤 숫자를 생성하기 위해 SecureRandom을 사용.
        SecureRandom secureRandom = new SecureRandom();
        // 16바이트 크기의 랜덤 바이트 배열 생성.
        byte[] token = new byte[16];
        // 랜덤 바이트를 생성하여 token 배열에 채움.
        secureRandom.nextBytes(token);
        // 바이트 배열을 URL 안전한 Base64 문자열로 인코딩하여 반환.
        return Base64.getUrlEncoder().encodeToString(token);
    }

    // 세션에서 CSRF 토큰을 가져오는 메서드.
    public static String getTokenFromSession(HttpSession session) {
        // 세션에서 CSRF_TOKEN_ATTRIBUTE 이름으로 저장된 객체를 가져옴.
        Object token = session.getAttribute(CSRF_TOKEN_ATTRIBUTE);
        // 토큰이 null이 아니면 문자열로 변환하여 반환, 그렇지 않으면 null 반환.
        return token != null ? token.toString() : null;
    }

    // 세션에 CSRF 토큰을 설정하는 메서드.
    public static void setTokenInSession(HttpSession session, String token) {
        // 세션에 CSRF_TOKEN_ATTRIBUTE 이름으로 토큰을 저장.
        session.setAttribute(CSRF_TOKEN_ATTRIBUTE, token);
    }

    // 요청에서 제공된 CSRF 토큰이 세션에 저장된 토큰과 일치하는지 확인하는 메서드.
    public static boolean validateToken(HttpServletRequest request) {
        // 세션에서 저장된 CSRF 토큰을 가져옴.
        String sessionToken = getTokenFromSession(request.getSession());
        // 요청 파라미터에서 CSRF 토큰을 가져옴 (보통 폼 데이터에서 전송된 값).
        String requestToken = request.getParameter("csrfToken");
        // 세션 토큰이 null이 아니고, 세션 토큰과 요청 토큰이 일치하면 true 반환, 그렇지 않으면 false 반환.
        return sessionToken != null && sessionToken.equals(requestToken);
    }
}
