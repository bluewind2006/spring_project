package ktc.secure.coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtcSecuecodingUntrustedUrlSecurityCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtcSecuecodingUntrustedUrlSecurityCaseApplication.class, args);
	}

}
