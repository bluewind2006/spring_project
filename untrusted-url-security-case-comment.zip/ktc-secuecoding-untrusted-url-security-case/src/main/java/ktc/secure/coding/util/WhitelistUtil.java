package ktc.secure.coding.util;
import java.util.Set;
import java.util.logging.Logger;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

//이 클래스가 Spring의 컴포넌트로 관리되며, 스프링 애플리케이션 컨텍스트에서 빈으로 등록됨을 나타냄
@Component

//이 클래스가 애플리케이션 설정 파일(application.properties 또는 application.yml)에 정의된
//설정을 바인딩할 수 있음을 나타냄. 여기서 "app"이라는 접두사가 붙은 속성들이 이 클래스에 매핑됨
@ConfigurationProperties(prefix = "app")
public class WhitelistUtil {

 // Logger 객체를 사용하여 로그를 기록함
 private static final Logger logger = Logger.getLogger(WhitelistUtil.class.getName());

 // 허용된 URL들을 저장하는 Set 객체. 이 Set은 중복을 허용하지 않으며, 허용된 URL 목록을 관리함
 private Set<String> whitelistedUrls;

 // whitelistedUrls에 접근할 수 있는 getter 메서드
 public Set<String> getWhitelistedUrls() {
     return whitelistedUrls;
 }

 // whitelistedUrls를 설정할 수 있는 setter 메서드
 // 애플리케이션 설정 파일에서 주입된 값들을 이 메서드를 통해 whitelistedUrls에 설정함
 public void setWhitelistedUrls(Set<String> whitelistedUrls) {
     // 주어진 URL 목록을 인스턴스 변수에 할당
     this.whitelistedUrls = whitelistedUrls;
     
     // 허용된 URL 리스트가 초기화되었음을 로그로 기록
     logger.info("Whitelisted URLs initialized."); // URL 리스트 자체를 로깅하지 않음
 }

 // 주어진 URL이 whitelistedUrls에 포함되어 있는지를 확인하는 메서드
 // whitelistedUrls가 null이 아니고, 주어진 URL이 Set에 포함되어 있으면 true를 반환, 그렇지 않으면 false를 반환
 public boolean isWhitelisted(String url) {
     return whitelistedUrls != null && whitelistedUrls.contains(url);
 }
}
