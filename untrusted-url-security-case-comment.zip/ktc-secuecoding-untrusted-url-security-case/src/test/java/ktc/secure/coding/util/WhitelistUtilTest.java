package ktc.secure.coding.util;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

import java.util.Set;
import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@Import(WhitelistUtilTest.WhitelistUtilTestConfiguration.class)
public class WhitelistUtilTest {

    @Autowired
    private WhitelistUtil whitelistUtil;

    @TestConfiguration
    static class WhitelistUtilTestConfiguration {

        @Bean
        public WhitelistUtil whitelistUtil() {
            WhitelistUtil whitelistUtil = new WhitelistUtil();
            Set<String> whitelistedUrls = new HashSet<>();
            whitelistedUrls.add("http://example.com");
            whitelistedUrls.add("http://test.com");
            whitelistUtil.setWhitelistedUrls(whitelistedUrls);
            return whitelistUtil;
        }
    }

    @Test
    public void testUrlIsWhitelisted() {
        assertTrue(whitelistUtil.isWhitelisted("http://example.com"));
        assertTrue(whitelistUtil.isWhitelisted("http://test.com"));
    }

    @Test
    public void testUrlIsNotWhitelisted() {
        assertFalse(whitelistUtil.isWhitelisted("http://notwhitelisted.com"));
    }
}
