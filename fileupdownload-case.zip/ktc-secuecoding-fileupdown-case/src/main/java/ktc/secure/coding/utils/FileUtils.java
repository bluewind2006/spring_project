package ktc.secure.coding.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;

@Component
public class FileUtils {

    @Value("${file.filepath}")
    private String filePath;

    @Value("${file.filewhiteListext}")
    private String fileWhiteListExt;

    @Value("${file.filemaxsize}")
    private long fileMaxSize;

    private Set<String> whiteListExtensions;

    public FileUtils() {
        whiteListExtensions = new HashSet<>();
    }

    @Value("${file.filewhiteListext}")
    public void setFileWhiteListExt(String fileWhiteListExt) {
        String[] extensions = fileWhiteListExt.split(",");
        for (String ext : extensions) {
            whiteListExtensions.add(ext.trim().toLowerCase());
        }
    }

    public boolean filePathBlackList(String path) {
        File file = new File(path).getAbsoluteFile();
        return file.getPath().contains("..");
    }

    public String getFileExt(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex == -1) ? "" : fileName.substring(dotIndex + 1).toLowerCase();
    }

    public void validateFile(MultipartFile file) throws IllegalArgumentException, IOException {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("File is empty");
        }

        String fileExt = getFileExt(file.getOriginalFilename());
        if (!whiteListExtensions.contains(fileExt)) {
            throw new IllegalArgumentException("Invalid file extension");
        }

        if (file.getSize() > fileMaxSize) {
            throw new IllegalArgumentException("File size exceeds the maximum limit");
        }
    }

    public FileInfo parseInsertFileInfo(MultipartFile file) throws IllegalArgumentException, IOException {
        validateFile(file);

        String originalFileName = file.getOriginalFilename();
        String fileExt = getFileExt(originalFileName);
        String newFileName = CommonUtils.getRandomString() + "." + fileExt;
        String fullPath = Paths.get(filePath, newFileName).toString();

        if (filePathBlackList(fullPath)) {
            throw new IllegalArgumentException("Invalid file path");
        }

        Files.createDirectories(Paths.get(filePath));
        file.transferTo(new File(fullPath));

        return new FileInfo(originalFileName, newFileName);
    }

    public File downloadFile(String fileName) throws IllegalArgumentException {
        String fullPath = Paths.get(filePath, fileName).toString();

        if (filePathBlackList(fullPath)) {
            throw new IllegalArgumentException("Invalid file path");
        }

        File file = new File(fullPath);
        if (!file.exists()) {
            throw new IllegalArgumentException("File not found");
        }

        return file;
    }

    public String getFilePath() {
        return filePath;
    }
}
