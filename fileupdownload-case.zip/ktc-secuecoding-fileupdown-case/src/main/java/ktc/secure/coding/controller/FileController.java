package ktc.secure.coding.controller;


import ktc.secure.coding.utils.FileUtils;
import ktc.secure.coding.utils.FileInfo;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/files")
public class FileController {

    private static final Logger logger = LoggerFactory.getLogger(FileController.class);

    @Autowired
    private FileUtils fileUtils;

    private List<FileInfo> uploadedFiles = new ArrayList<>();

    @GetMapping
    public String listFiles(Model model) {
        model.addAttribute("files", uploadedFiles);
        return "file-list";
    }

    @GetMapping("/upload")
    public String showUploadForm() {
        return "file-upload";
    }

    @PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file, Model model) {
        try {
            FileInfo fileInfo = fileUtils.parseInsertFileInfo(file);
            uploadedFiles.add(fileInfo);
            model.addAttribute("message", "File uploaded successfully: " + fileInfo.getOriginalFileName());
        } catch (IllegalArgumentException e) {
            model.addAttribute("message", "File upload failed: " + e.getMessage());
            logger.error("File upload failed: " + e.getMessage(), e);
        } catch (IOException e) {
            model.addAttribute("message", "File upload failed due to IO error: " + e.getMessage());
            logger.error("File upload failed due to IO error: " + e.getMessage(), e);
        }
        return "file-upload";
    }

    @GetMapping("/download/{fileName}")
    public ResponseEntity<?> downloadFile(@PathVariable("fileName") String fileName) {
        try {
            File file = fileUtils.downloadFile(fileName);
            FileSystemResource resource = new FileSystemResource(file);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } catch (IllegalArgumentException e) {
            logger.error("File download failed: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Error: " + e.getMessage());
        } catch (Exception e) {
            logger.error("File download failed due to unexpected error: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }
}
