package ktc.secure.coding.utils;


public class FileInfo {
    private String originalFileName;
    private String storedFileName;

    public FileInfo(String originalFileName, String storedFileName) {
        this.originalFileName = originalFileName;
        this.storedFileName = storedFileName;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public String getStoredFileName() {
        return storedFileName;
    }
}
