package ktc.secure.coding.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class SecureCommandExecutor {

    // 허용된 명령어 리스트. 현재는 "whoami" 명령어만 허용됨.
    private static final List<String> ALLOWED_COMMANDS = List.of("whoami");

    // 명령어 또는 인자에 포함되면 안 되는 위험한 문자들을 정의한 정규 표현식 패턴.
    // 예: &, |, ;, `, $, <, >, (), [], *, ', ", 개행 문자(\n, \r), 백슬래시(\), 하이픈(-) 등
    private static final Pattern DANGEROUS_CHAR_PATTERN = Pattern.compile("[&|;`$<>\\(\\)\\[\\]\\*\\'\"\\n\\r\\\\-]");

    // 제어 문자를 탐지하기 위한 정규 표현식 패턴.
    // 예: NULL 문자(\x00)부터 ESC 문자(\x1F)까지, 그리고 DEL 문자(\x7F)
    private static final Pattern CONTROL_CHAR_PATTERN = Pattern.compile("[\\x00-\\x1F\\x7F]");

    // 허용된 인자 패턴: 알파벳 대소문자, 숫자, 밑줄(_)만 허용.
    private static final Pattern ALLOWED_ARGUMENT_PATTERN = Pattern.compile("^[a-zA-Z0-9_]+$");

    // 경로 순회를 탐지하기 위한 정규 표현식 패턴.
    // 예: ..(상위 디렉토리 이동) 또는 ~(홈 디렉토리) 사용을 탐지.
    private static final Pattern PATH_TRAVERSAL_PATTERN = Pattern.compile(".*(\\.{2}|~).*");

    // 파일 포함 공격을 탐지하기 위한 정규 표현식 패턴.
    // 예: /etc/passwd, URL(http, https, ftp), NULL 바이트(%00), 경로 순회(%2e%2e) 등을 탐지.
    private static final Pattern FILE_INCLUSION_PATTERN = Pattern.compile(".*(etc/passwd|http|https|ftp|file|%00|%2e%2e).*", Pattern.CASE_INSENSITIVE);

    // 명령어를 실행하는 메서드.
    public String executeCommand(String command, List<String> args) throws Exception {
        // 명령어가 허용된 명령어인지 검증.
        if (!isValidCommand(command)) {
            throw new IllegalArgumentException("Invalid command: " + command);
        }

        // 각 인자들이 유효한지 검증.
        for (String arg : args) {
            if (!isValidArgument(arg)) {
                throw new IllegalArgumentException("Invalid argument: " + arg);
            }
        }

        // 명령어와 인자를 함께 저장할 리스트 생성.
        List<String> commandWithArgs = new ArrayList<>();
        commandWithArgs.add(command);
        commandWithArgs.addAll(args);

        // 프로세스를 생성하고, 에러 스트림을 표준 출력 스트림으로 리다이렉트.
        ProcessBuilder processBuilder = new ProcessBuilder(commandWithArgs);
        processBuilder.redirectErrorStream(true);

        // 프로세스를 시작하고 명령어를 실행.
        Process process = processBuilder.start();
        StringBuilder result = new StringBuilder();

        // 명령어 실행 결과를 읽어서 StringBuilder에 저장.
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line).append("\n");
            }
        }

        // 프로세스가 종료될 때까지 대기하고, 종료 코드 확인.
        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new RuntimeException("Command failed with exit code: " + exitCode);
        }

        // 실행 결과 반환.
        return result.toString();
    }

    // 명령어가 허용된 명령어 리스트에 포함되어 있는지 확인.
    private boolean isValidCommand(String command) {
        return ALLOWED_COMMANDS.contains(command);
    }

    // 인자가 유효한지 확인하는 메서드.
    private boolean isValidArgument(String arg) {
        return ALLOWED_ARGUMENT_PATTERN.matcher(arg).matches() &&  // 허용된 인자 패턴에 맞는지 확인.
               !DANGEROUS_CHAR_PATTERN.matcher(arg).find() &&  // 위험한 문자가 포함되지 않았는지 확인.
               !CONTROL_CHAR_PATTERN.matcher(arg).find() &&  // 제어 문자가 포함되지 않았는지 확인.
               !PATH_TRAVERSAL_PATTERN.matcher(arg).find() &&  // 경로 순회 문자가 포함되지 않았는지 확인.
               !FILE_INCLUSION_PATTERN.matcher(arg).find() &&  // 파일 포함 공격 패턴이 포함되지 않았는지 확인.
               !isPathTraversal(arg);  // 경로 순회 여부를 확인하는 추가 검증.
    }

    // 경로 순회 공격을 추가적으로 확인하는 메서드.
    private boolean isPathTraversal(String path) {
        try {
            // 기준(base) 디렉토리의 실제 경로를 가져옴.
            Path basePath = Paths.get("/safe/base/directory").toRealPath();
            // 인자로 전달된 경로를 기준 디렉토리 아래로 해석하여 실제 경로를 가져옴.
            Path targetPath = basePath.resolve(path).normalize().toRealPath();
            // 대상 경로가 기준 디렉토리 내부에 있는지 확인.
            return !targetPath.startsWith(basePath);
        } catch (InvalidPathException | IOException e) {
            return true;  // 경로가 유효하지 않거나 오류가 발생하면 경로 순회로 간주.
        }
    }
}
