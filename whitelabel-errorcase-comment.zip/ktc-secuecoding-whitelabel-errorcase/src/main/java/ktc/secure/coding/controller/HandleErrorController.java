package ktc.secure.coding.controller;

import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

//@Controller 애노테이션은 이 클래스가 Spring MVC의 컨트롤러임을 나타냅니다.
//이 클래스는 애플리케이션에서 발생하는 에러를 처리하고 에러 페이지를 렌더링하는 역할을 합니다.
@Controller
public class HandleErrorController implements ErrorController {

 // ErrorAttributes는 Spring Boot에서 제공하는 인터페이스로,
 // 발생한 에러의 세부 정보를 추출하는 데 사용됩니다.
 private final ErrorAttributes errorAttributes;

 // 생성자는 ErrorAttributes 객체를 주입받아 HandleErrorController를 초기화합니다.
 public HandleErrorController(ErrorAttributes errorAttributes) {
     this.errorAttributes = errorAttributes;
 }

 // /error 경로로 요청이 들어오면 이 메서드가 호출됩니다.
 // WebRequest 객체를 통해 요청의 세부 정보를 받아오고, Model 객체를 통해 뷰에 데이터를 전달합니다.
 @RequestMapping("/error")
 public String renderErrorPage(WebRequest webRequest, Model model) {
     // 에러 세부 정보를 추출합니다. 여기서 스택 트레이스도 포함됩니다.
     Map<String, Object> errorDetails = errorAttributes.getErrorAttributes(webRequest, ErrorAttributeOptions.of(ErrorAttributeOptions.Include.STACK_TRACE));
     
     // 에러 세부 정보에서 추출한 각 속성을 모델에 추가하여, 뷰에서 사용 가능하게 합니다.
     model.addAttribute("timestamp", errorDetails.get("timestamp"));  // 에러 발생 시각
     model.addAttribute("status", errorDetails.get("status"));        // HTTP 상태 코드
     model.addAttribute("error", errorDetails.get("error"));          // 에러의 간단한 설명
     model.addAttribute("message", errorDetails.get("message"));      // 에러 메시지
     model.addAttribute("path", errorDetails.get("path"));            // 에러가 발생한 경로
     model.addAttribute("trace", errorDetails.get("trace"));          // 스택 트레이스 (있을 경우)
     
     // "baseError" 뷰 이름을 반환하여, 에러 페이지를 렌더링합니다.
     return "baseError";
 }

 // 요청된 에러에 대한 HTTP 상태 코드를 반환하는 헬퍼 메서드입니다.
 private HttpStatus getErrorCode(WebRequest webRequest) {
     // 에러 세부 정보를 추출합니다. 기본 옵션을 사용하여 스택 트레이스를 포함하지 않습니다.
     Map<String, Object> errorDetails = errorAttributes.getErrorAttributes(webRequest, ErrorAttributeOptions.defaults());
     
     // 상태 코드를 추출하고, HttpStatus 객체로 변환하여 반환합니다.
     int statusCode = (int) errorDetails.get("status");
     return HttpStatus.valueOf(statusCode);
 }
}
