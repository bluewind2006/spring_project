package ktc.secure.coding.config.error.exception;

import ktc.secure.coding.config.error.ErrorCode;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;

import java.net.URI;

public class BusinessBaseException extends RuntimeException {
    private final ProblemDetail problemDetail;

    public BusinessBaseException(ErrorCode errorCode) {
        super(errorCode.getMessage());
        this.problemDetail = createProblemDetail(errorCode);
    }

    public BusinessBaseException(ErrorCode errorCode, Throwable cause) {
        super(errorCode.getMessage(), cause);
        this.problemDetail = createProblemDetail(errorCode);
    }

    private ProblemDetail createProblemDetail(ErrorCode errorCode) {
        ProblemDetail problemDetail = ProblemDetail.forStatusAndDetail(HttpStatus.valueOf(errorCode.getStatus()), errorCode.getMessage());
        problemDetail.setType(URI.create("/errors/" + errorCode.getCode()));
        problemDetail.setTitle(errorCode.name());
        problemDetail.setProperty("code", errorCode.getCode());
        return problemDetail;
    }

    public ProblemDetail getProblemDetail() {
        return problemDetail;
    }
}
