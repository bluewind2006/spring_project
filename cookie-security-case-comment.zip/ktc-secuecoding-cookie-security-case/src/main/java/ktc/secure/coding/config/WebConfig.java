package ktc.secure.coding.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

//Spring MVC 설정 클래스임을 나타내는 어노테이션
@Configuration
public class WebConfig implements WebMvcConfigurer {

 // 특정 URL 패턴에 대해 뷰를 연결하는 설정을 추가하는 메서드
 @Override
 public void addViewControllers(ViewControllerRegistry registry) {
     // "/login" URL 요청에 대해 "login" 뷰 이름을 반환하도록 설정
     registry.addViewController("/login").setViewName("login");
     
     // "/home" URL 요청에 대해 "home" 뷰 이름을 반환하도록 설정
     registry.addViewController("/home").setViewName("home");

     // "/login?expired=true" URL 요청에 대해 "login" 뷰 이름을 반환하도록 설정
     registry.addViewController("/login?expired=true").setViewName("login");
 }
}
