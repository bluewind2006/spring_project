package ktc.secure.coding.handler;

import ktc.secure.coding.service.NotificationService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.web.session.SessionInformationExpiredEvent;
import org.springframework.security.web.session.SessionInformationExpiredStrategy;
import org.springframework.stereotype.Component;

//이 클래스가 Spring의 빈으로 관리되는 컴포넌트임을 나타내는 어노테이션
@Component
public class CustomSessionInformationExpiredStrategy implements SessionInformationExpiredStrategy {

 // NotificationService를 자동으로 주입받음
 @Autowired
 private NotificationService notificationService;

 // 세션이 만료되었을 때 호출되는 메서드
 @Override
 public void onExpiredSessionDetected(SessionInformationExpiredEvent event) {
     // 만료된 세션 정보를 가져옴
     SessionInformation sessionInformation = event.getSessionInformation();
     
     // 만료된 세션의 ID를 가져옴
     String sessionId = sessionInformation.getSessionId();
     
     // NotificationService를 통해 사용자에게 알림을 보냄
     // 메시지 내용: "다른 로그인 시도가 감지되었습니다."
     notificationService.notifyUser(sessionId, "Another login attempt detected for your account.");
 }
}
