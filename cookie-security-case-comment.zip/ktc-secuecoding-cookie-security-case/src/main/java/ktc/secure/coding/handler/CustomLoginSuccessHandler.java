package ktc.secure.coding.handler;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import java.io.IOException;

//AuthenticationSuccessHandler 인터페이스를 구현한 커스텀 로그인 성공 핸들러 클래스
public class CustomLoginSuccessHandler implements AuthenticationSuccessHandler {

 // 인증 성공 시 호출되는 메서드
 @Override
 public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                     Authentication authentication) throws IOException, ServletException {
   

     // 현재 세션이 존재하는지 확인
     if (request.getSession(false) != null) {
         // 기존 세션이 존재하면 해당 세션을 무효화하여 세션 하이재킹을 방지
         request.getSession(false).invalidate();
     }

     // 새로운 세션을 생성
     request.getSession(true);

     // 클라이언트에 302 상태 코드(Found)를 설정하여 리다이렉션을 유도
     response.setStatus(HttpServletResponse.SC_FOUND);
     // 클라이언트를 "/home" 페이지로 리다이렉트
     response.setHeader("Location", "/home");
 }
}
