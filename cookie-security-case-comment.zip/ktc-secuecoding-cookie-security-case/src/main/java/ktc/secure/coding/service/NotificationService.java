package ktc.secure.coding.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

//이 클래스가 비즈니스 로직을 처리하는 서비스 컴포넌트임을 나타내는 어노테이션
@Service
public class NotificationService {

 // WebSocket 메시지를 전송하는 데 사용되는 SimpMessagingTemplate 객체를 정의
 private final SimpMessagingTemplate messagingTemplate;

 // SimpMessagingTemplate을 주입받는 생성자
 @Autowired
 public NotificationService(SimpMessagingTemplate messagingTemplate) {
     this.messagingTemplate = messagingTemplate;
 }

 // 특정 사용자에게 알림을 전송하는 메서드
 public void notifyUser(String sessionId, String message) {
     // 사용자에게 메시지를 전송함
     // sessionId: 메시지를 수신할 사용자의 세션 ID
     // "/queue/notify": 사용자가 메시지를 수신할 대상 목적지
     // message: 전송할 메시지 내용
     messagingTemplate.convertAndSendToUser(sessionId, "/queue/notify", message);
 }
}
