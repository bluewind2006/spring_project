package ktc.secure.coding.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
//Spring에서 WebSocket 메시지 브로커를 설정하기 위한 구성 클래스임을 나타내는 어노테이션
@Configuration
//WebSocket 메시지 브로커를 활성화하는 어노테이션
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

 // 메시지 브로커를 구성하는 메서드
 @Override
 public void configureMessageBroker(MessageBrokerRegistry config) {
     // 간단한 메모리 기반 메시지 브로커를 활성화하여 "/topic"과 "/queue"로 시작하는 경로를 브로커가 처리하도록 설정
     config.enableSimpleBroker("/topic", "/queue");
     
     // 애플리케이션에서 메시지를 처리할 때 사용하는 경로의 접두사를 "/app"으로 설정
     // 예를 들어, 클라이언트가 "/app/hello"로 메시지를 보내면, 이 메시지는 컨트롤러에서 처리됨
     config.setApplicationDestinationPrefixes("/app");
 }

 // STOMP 프로토콜을 사용하여 WebSocket 엔드포인트를 등록하는 메서드
 @Override
 public void registerStompEndpoints(StompEndpointRegistry registry) {
     // "/ws"라는 엔드포인트를 WebSocket 엔드포인트로 등록
     // 이 엔드포인트는 클라이언트가 WebSocket 연결을 수립하는 데 사용됨
     // 또한, SockJS를 사용하도록 설정하여 WebSocket을 지원하지 않는 브라우저에 대한 폴백 옵션 제공
     registry.addEndpoint("/ws").withSockJS();
 }
}
