package ktc.secure.coding.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.session.ConcurrentSessionControlAuthenticationStrategy;
import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.security.web.session.SessionInformationExpiredStrategy;

import ktc.secure.coding.handler.CustomLoginSuccessHandler;
import ktc.secure.coding.handler.CustomSessionInformationExpiredStrategy;

//Spring Security 설정 클래스임을 나타내는 어노테이션
@Configuration
public class SecurityConfig {

 // SecurityFilterChain 빈을 정의하여 HTTP 보안 설정을 구성
 @Bean
 public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
     http
         // 모든 HTTP 요청에 대해 인증이 필요하도록 설정
         .authorizeHttpRequests(authorize -> authorize
             .anyRequest().authenticated()  // 모든 요청은 인증되어야 함
         )
         // 폼 로그인 설정
         .formLogin(form -> form
             .loginPage("/login")  // 커스텀 로그인 페이지 경로 지정
             .permitAll()  // 로그인 페이지 접근은 모든 사용자에게 허용
             .successHandler(new CustomLoginSuccessHandler())  // 로그인 성공 시 커스텀 핸들러 실행
             .failureHandler(authenticationFailureHandler())  // 로그인 실패 시 커스텀 핸들러 실행
             .defaultSuccessUrl("/home", true)  // 로그인 성공 시 이동할 기본 URL 지정, 항상 /home으로 이동
         )
         // 로그아웃 설정
         .logout(logout -> logout
             .logoutSuccessUrl("/login?logout=true")  // 로그아웃 성공 시 이동할 URL 지정
             .permitAll()  // 로그아웃 페이지 접근은 모든 사용자에게 허용
         )
         // 세션 관리 설정
         .sessionManagement(session -> session
             .maximumSessions(1)  // 최대 허용 세션 수를 1로 설정
             .maxSessionsPreventsLogin(true)  // 최대 세션 수를 초과하면 추가 로그인을 방지
             .expiredSessionStrategy(sessionInformationExpiredStrategy())  // 세션이 만료될 때 실행할 전략 지정
             .sessionRegistry(sessionRegistry())  // 세션 레지스트리 빈 설정
         );

     // 구성된 HttpSecurity 객체를 빌드하여 SecurityFilterChain을 반환
     return http.build();
 }

 // 세션 레지스트리를 관리하는 SessionRegistryImpl 빈을 정의
 @Bean
 public SessionRegistryImpl sessionRegistry() {
     return new SessionRegistryImpl();
 }

 // HTTP 세션 이벤트를 게시하는 HttpSessionEventPublisher 빈을 정의
 @Bean
 public HttpSessionEventPublisher httpSessionEventPublisher() {
     return new HttpSessionEventPublisher();
 }

 // 세션 인증 전략을 관리하는 SessionAuthenticationStrategy 빈을 정의
 @Bean
 public SessionAuthenticationStrategy sessionAuthenticationStrategy() {
     // 동시 세션 제어 전략을 생성하고 설정
     ConcurrentSessionControlAuthenticationStrategy strategy = 
             new ConcurrentSessionControlAuthenticationStrategy(sessionRegistry());
     strategy.setMaximumSessions(1);  // 최대 세션 수를 1로 설정
     strategy.setExceptionIfMaximumExceeded(true);  // 최대 세션 수를 초과하면 예외 발생

     // 세션을 등록하는 전략을 반환
     return new RegisterSessionAuthenticationStrategy(sessionRegistry());
 }

 // 인증 실패 시 실행할 커스텀 AuthenticationFailureHandler 빈을 정의
 @Bean
 public AuthenticationFailureHandler authenticationFailureHandler() {
     return (request, response, exception) -> {
         // 최대 세션 수를 초과한 경우 특정 URL로 리다이렉트
         if (exception.getMessage().equalsIgnoreCase("Maximum sessions of 1 for this principal exceeded")) {
             response.sendRedirect("/login?error=already-logged-in");
         } else {
             // 일반적인 인증 실패 시 리다이렉트
             response.sendRedirect("/login?error=true");
         }
     };
 }

 // 세션 정보가 만료되었을 때 실행할 전략을 정의하는 SessionInformationExpiredStrategy 빈을 정의
 @Bean
 public SessionInformationExpiredStrategy sessionInformationExpiredStrategy() {
     return new CustomSessionInformationExpiredStrategy();
 }
}
