package ktc.secure.coding.service;

import org.springframework.stereotype.Service;

import org.springframework.stereotype.Service;

import org.springframework.stereotype.Service;

@Service
public class PasswordValidator {

    public boolean isEmpty(String password) {
        return password == null || password.trim().isEmpty();
    }

    public boolean isValidLength(String password) {
        String regex1 = "^(?=.*[a-zA-Z])(?=.*\\d).{10,}$"; // 최소 2종류 이상의 문자 조합으로 10자리 이상
        String regex2 = "^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[^a-zA-Z\\d]).{8,}$"; // 최소 3종류 이상의 문자 조합으로 8자리 이상

        return password.length() >= 8 && (password.matches(regex1) || password.matches(regex2));
    }

    public boolean isSimilarToUsername(String username, String password) {
        if (username.length() <= 4) {
            return false;
        }

        int matchCount = 0;
        for (char c : username.toCharArray()) {
            if (password.indexOf(c) >= 0) {
                matchCount++;
            }
        }

        return matchCount >= 4;
    }

    public boolean isSequentialOrRepeated(String password) {
        return containsRepeatedChars(password) || containsSequentialChars(password);
    }

    private boolean containsRepeatedChars(String password) {
        for (int i = 0; i < password.length() - 3; i++) {
            char current = password.charAt(i);
            if (password.charAt(i + 1) == current && password.charAt(i + 2) == current && password.charAt(i + 3) == current) {
                return true;
            }
        }
        return false;
    }

    private boolean containsSequentialChars(String password) {
        for (int i = 0; i < password.length() - 3; i++) {
            if (isSequential(password.charAt(i), password.charAt(i + 1), password.charAt(i + 2), password.charAt(i + 3))) {
                return true;
            }
        }
        return false;
    }

    private boolean isSequential(char a, char b, char c, char d) {
        return (b == a + 1 && c == b + 1 && d == c + 1) || (b == a - 1 && c == b - 1 && d == c - 1);
    }
}