package ktc.secure.coding.service;

import org.springframework.stereotype.Service;

import org.springframework.stereotype.Service;

@Service
public class PasswordValidator {

    public boolean isEmpty(String password) {
        return password == null || password.trim().isEmpty();
    }

    public boolean isValidLength(String password) {
        String regex1 = "^(?=.*[a-zA-Z])(?=.*\\d).{10,}$";
        String regex2 = "^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[^a-zA-Z\\d]).{8,}$";

        return password.matches(regex1) || password.matches(regex2);
    }

    public boolean isSimilarToUsername(String username, String password) {
        if (username.length() <= 4) {
            return false;
        }

        int matchCount = 0;
        for (char c : username.toCharArray()) {
            if (password.indexOf(c) >= 0) {
                matchCount++;
            }
        }

        return matchCount >= 4;
    }

    public boolean isSequentialOrRepeated(String password) {
        return samePwd(password) || continuousPwd(password);
    }

    private boolean samePwd(String pwd) {
        for (int i = 0; i < pwd.length() - 3; i++) {
            char current = pwd.charAt(i);
            if (pwd.charAt(i + 1) == current && pwd.charAt(i + 2) == current && pwd.charAt(i + 3) == current) {
                return true;
            }
        }
        return false;
    }

    private boolean continuousPwd(String pwd) {
        for (int i = 0; i < pwd.length() - 3; i++) {
            if (isSequential(pwd.charAt(i), pwd.charAt(i + 1), pwd.charAt(i + 2), pwd.charAt(i + 3))) {
                return true;
            }
        }
        return false;
    }

    private boolean isSequential(char a, char b, char c, char d) {
        return (b == a + 1 && c == b + 1 && d == c + 1) || (b == a - 1 && c == b - 1 && d == c - 1);
    }
}