package ktc.secure.coding.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ktc.secure.coding.service.PasswordValidator;

@Controller
@RequestMapping("/password")
public class PasswordValidatorController {

    @Autowired
    private PasswordValidator passwordValidator;

    @GetMapping("/validate")
    public String validatePasswordForm() {
        return "validate";
    }

    @PostMapping("/validate")
    public String validatePassword(@RequestParam("username") String username, @RequestParam("password") String password, Model model) {
        String message;
        if (passwordValidator.isEmpty(password)) {
            message = "Password is empty.";
        } else if (!passwordValidator.isValidLength(password)) {
            message = "Password does not meet length requirements.";
        } else if (passwordValidator.isSimilarToUsername(username, password)) {
            message = "Password is too similar to the username.";
        } else if (passwordValidator.isSequentialOrRepeated(password)) {
            message = "Password contains sequential or repeated characters.";
        } else {
            message = "Password is valid.";
        }

        model.addAttribute("message", message);
        return "result";
    }
}