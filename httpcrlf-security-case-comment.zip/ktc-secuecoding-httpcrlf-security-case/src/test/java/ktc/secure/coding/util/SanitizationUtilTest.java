package ktc.secure.coding.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class SanitizationUtilTest {

    @Test
    public void testSanitizeInput() {
        String[] payloads = {
            // Test for reflected XSS
            "en-US;%0D%0AContent-Type: text/html%0D%0AContent-Length:25%0D%0A%0D%0A<script>alert(1)</script>",
            "%0D%0AContent-Length:35%0D%0AX-XSS-Protection:0%0D%0A%0D%0A23%0D%0A<svg onload=alert(document.domain)>%0D%0A0%0D%0A/%2f%2e%2e",
            // Test for HTTP request smuggling
            "GET / HTTP/1.1%0D%0AHost: site.com%0D%0AContent-Length: 0%0D%0A%0D%0APOST /evil HTTP/1.1%0D%0AHost: evil.com%0D%0AContent-Length: 4%0D%0A%0D%0Atest",
            // Test for email injection
            "peter%0D%0ABcc: notaniceguy@company.com",
            "peter%0D%0AContent-Type: text/html%0D%0A<html><body>Injected</body></html>",
            // Test for log injection
            "peter:False%0D%0A1708853860227:admin:True",
            "peter:False%0D%0A%0D%0A1708853860227:admin:True%0D%0A",
            // Existing tests
            "%0AHeader-Test:BLATRUC",
            "%0A%20Header-Test:BLATRUC",
            "%20%0AHeader-Test:BLATRUC",
            "%23%OAHeader-Test:BLATRUC",
            "%E5%98%8A%E5%98%8DHeader-Test:BLATRUC",
            "%E5%98%8A%E5%98%8D%0AHeader-Test:BLATRUC",
            "%3F%0AHeader-Test:BLATRUC",
            "crlf%0AHeader-Test:BLATRUC",
            "crlf%0A%20Header-Test:BLATRUC",
            "crlf%20%0AHeader-Test:BLATRUC",
            "crlf%23%OAHeader-Test:BLATRUC",
            "crlf%E5%98%8A%E5%98%8DHeader-Test:BLATRUC",
            "crlf%E5%98%8A%E5%98%8D%0AHeader-Test:BLATRUC",
            "crlf%3F%0AHeader-Test:BLATRUC",
            "%0DHeader-Test:BLATRUC",
            "%0D%20Header-Test:BLATRUC",
            "%20%0DHeader-Test:BLATRUC",
            "%23%0DHeader-Test:BLATRUC",
            "%23%0AHeader-Test:BLATRUC",
            "%E5%98%8A%E5%98%8DHeader-Test:BLATRUC",
            "%E5%98%8A%E5%98%8D%0DHeader-Test:BLATRUC",
            "%3F%0DHeader-Test:BLATRUC",
            "crlf%0DHeader-Test:BLATRUC",
            "crlf%0D%20Header-Test:BLATRUC",
            "crlf%20%0DHeader-Test:BLATRUC",
            "crlf%23%0DHeader-Test:BLATRUC",
            "crlf%23%0AHeader-Test:BLATRUC",
            "crlf%E5%98%8A%E5%98%8DHeader-Test:BLATRUC",
            "crlf%E5%98%8A%E5%98%8D%0DHeader-Test:BLATRUC",
            "crlf%3F%0DHeader-Test:BLATRUC",
            "%0D%0AHeader-Test:BLATRUC",
            "%0D%0A%20Header-Test:BLATRUC",
            "%20%0D%0AHeader-Test:BLATRUC",
            "%23%0D%0AHeader-Test:BLATRUC",
            "\\r\\nHeader-Test:BLATRUC",
            " \\r\\n Header-Test:BLATRUC",
            "\\r\\n Header-Test:BLATRUC",
            "%5cr%5cnHeader-Test:BLATRUC",
            "%E5%98%8A%E5%98%8DHeader-Test:BLATRUC",
            "%E5%98%8A%E5%98%8D%0D%0AHeader-Test:BLATRUC",
            "%3F%0D%0AHeader-Test:BLATRUC",
            "crlf%0D%0AHeader-Test:BLATRUC",
            "crlf%0D%0A%20Header-Test:BLATRUC",
            "crlf%20%0D%0AHeader-Test:BLATRUC",
            "crlf%23%0D%0AHeader-Test:BLATRUC",
            "crlf\\r\\nHeader-Test:BLATRUC",
            "crlf%5cr%5cnHeader-Test:BLATRUC",
            "crlf%E5%98%8A%E5%98%8DHeader-Test:BLATRUC",
            "crlf%E5%98%8A%E5%98%8D%0D%0AHeader-Test:BLATRUC",
            "crlf%3F%0D%0AHeader-Test:BLATRUC",
            "%0D%0A%09Header-Test:BLATRUC",
            "crlf%0D%0A%09Header-Test:BLATRUC",
            "%250AHeader-Test:BLATRUC",
            "%25250AHeader-Test:BLATRUC",
            "%%0A0AHeader-Test:BLATRUC",
            "%25%30AHeader-Test:BLATRUC",
            "%25%30%61Header-Test:BLATRUC",
            "%u000AHeader-Test:BLATRUC",
            "//www.google.com/%2F%2E%2E%0D%0AHeader-Test:BLATRUC",
            "/www.google.com/%2E%2E%2F%0D%0AHeader-Test:BLATRUC",
            "/google.com/%2F..%0D%0AHeader-Test:BLATRUC",
            "%%0a0aSet-Cookie:crlf=injection",
            "%0aSet-Cookie:crlf=injection",
            "%0d%0aSet-Cookie:crlf=injection",
            "%0dSet-Cookie:crlf=injection",
            "%23%0aSet-Cookie:crlf=injection",
            "%23%0d%0aSet-Cookie:crlf=injection",
            "%23%0dSet-Cookie:crlf=injection",
            "%25%30%61Set-Cookie:crlf=injection",
            "%25%30aSet-Cookie:crlf=injection",
            "%25%0aSet-Cookie:crlf=injection",
            "%25250aSet-Cookie:crlf=injection",
            "%2e%2e%2f%0d%0aSet-Cookie:crlf=injection",
            "%2e%2e%2f%0dSet-Cookie:crlf=injection",
            "%2e%2e%2f%0aSet-Cookie:crlf=injection",
            "%2F..%0d%0aSet-Cookie:crlf=injection",
            "%3f%0d%0aSet-Cookie:crlf=injection",
            "%u000aSet-Cookie:crlf=injection",
            "http://www.example.net/%0D%0ASet-Cookie:mycookie=myvalue",
            "http://example.com/%0d%0aContent-Length:35%0d%0aX-XSS-Protection:0%0d%0a%0d%0a23%0d%0a<svg onload=alert(document.domain)>%0d%0a0%0d%0a/%2f%2e%2e",
            "http://www.example.net/index.php?lang=en%0D%0AContent-Length%3A%200%0A%20%0AHTTP/1.1%20200%20OK%0AContent-Type%3A%20text/html%0ALast-Modified%3A%20Mon,%2027%20Oct%202060%2014%3A50%3A18%20GMT%0AContent-Length%3A%2034%0A%20%0A%3Chtml%3EYou%20have%20been%20Phished%3C/html%3E",
            "%E5%98%8A%E5%98%8Dcontent-type:text/html%E5%98%8A%E5%98%8Dlocation:%E5%98%8A%E5%98%8D%E5%98%8A%E5%98%8A%E5%98%BCsvg/onload=alert%28innerHTML%28%29%E5%98%BE"
        };

        for (String payload : payloads) {
            String sanitized = SanitizationUtil.sanitizeInput(payload);
            assertEquals(sanitized.replaceAll("[\\r\\n]", ""), sanitized, "Failed to sanitize: " + payload);
        }
    }
}