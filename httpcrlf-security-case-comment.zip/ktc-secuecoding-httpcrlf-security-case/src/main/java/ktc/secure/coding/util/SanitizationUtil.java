package ktc.secure.coding.util;

import java.util.regex.Pattern;

public class SanitizationUtil {

    // 유틸리티 클래스이므로 인스턴스화를 방지하기 위해 private 생성자를 사용.
    private SanitizationUtil() {
        // Utility class, prevent instantiation
    }

    // CRLF(캐리지 리턴 및 라인 피드) 문자를 비롯한 다양한 인코딩된 형태를 매칭하기 위한 정규식 패턴.
    // 이 패턴은 입력 문자열에서 이러한 특수 문자를 탐지하고 제거하기 위해 사용됨.
    private static final Pattern CRLF_PATTERN = Pattern.compile(
        "(%0D|%0A|%0d|%0a|\\r|\\n|\\\\r|\\\\n|%25|\\u000A|%25250A|%%0A0A|%25%30A|%25%30%61|%5cr|%5cn|%E5%98%8A|%E5%98%8D|%2e%2e%2f|%2F%2E%2E|%3C|%3E|%0D%0A)+",
        Pattern.CASE_INSENSITIVE
    );

    // 입력 문자열을 안전하게 정화하는 메서드.
    // 입력에 포함된 CRLF 문자와 해당 인코딩된 형태를 정규식 패턴을 사용하여 제거.
    public static String sanitizeInput(String input) {
        if (input == null) { // 입력이 null인 경우 null을 반환.
            return null;
        }
        // 입력 문자열에서 CRLF 패턴에 매칭되는 부분을 모두 빈 문자열로 대체하여 제거.
        return CRLF_PATTERN.matcher(input).replaceAll("");
    }
}
