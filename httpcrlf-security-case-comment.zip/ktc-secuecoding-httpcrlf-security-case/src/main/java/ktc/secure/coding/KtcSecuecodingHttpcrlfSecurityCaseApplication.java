package ktc.secure.coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtcSecuecodingHttpcrlfSecurityCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtcSecuecodingHttpcrlfSecurityCaseApplication.class, args);
	}

}
