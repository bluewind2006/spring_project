document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');
    const fileInput = document.querySelector('input[type="file"]');
    const allowedExtensions = ['.gif', '.jpg', '.jpeg', '.png', '.xls', '.xlsx', '.pdf'];
    
    form.addEventListener('submit', (event) => {
        const file = fileInput.files[0];
        if (file) {
            const filename = file.name;
            const extensionIndex = filename.lastIndexOf('.');
            const extension = extensionIndex > 0 ? filename.slice(extensionIndex).toLowerCase() : '';

            if (!allowedExtensions.includes(extension)) {
                event.preventDefault();
                alert('업로드 불가능한 확장자입니다.');
            }
        }
    });
});
