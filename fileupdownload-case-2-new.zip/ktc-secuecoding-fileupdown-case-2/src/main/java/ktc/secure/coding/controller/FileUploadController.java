package ktc.secure.coding.controller;


import ktc.secure.coding.exception.FileExtensionNotAllowedException;
import ktc.secure.coding.exception.FileTypeNotAllowedException;
import ktc.secure.coding.exception.FileSizeExceededException;
import ktc.secure.coding.exception.FileUploadException;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.constraints.NotNull;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Controller
@Validated
public class FileUploadController {

    @Value("${fileStorePath}")
    private String fileStorePath;

    @Value("${fileUpload.Extensions.General}")
    private String[] allowedExtensions;

    @Value("${fileUpload.maxSize}")
    private long maxSize;

    @Value("${fileDownload.Extensions}")
    private String[] downloadExtensions;

    private final Tika tika = new Tika();
    private final SecureRandom random = new SecureRandom();

    private static final Pattern FILENAME_PATTERN = Pattern.compile("^[a-zA-Z0-9._\\- ]+$");
    private static final Set<String> INVALID_FILENAMES = Set.of(
        "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
    );

    @GetMapping("/")
    public String index(Map<String, Object> model) {
        List<String> files = listUploadedFiles();
        model.put("files", files);
        return "index";
    }

    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") @NotNull MultipartFile file,
                                   RedirectAttributes redirectAttributes) throws IOException {

        try {
            String originalFilename = file.getOriginalFilename();
            if (originalFilename == null) {
                throw new FileUploadException("파일 이름이 유효하지 않습니다.");
            }
            String sanitizedFilename = sanitizeFilename(originalFilename);
            String extension = "." + FilenameUtils.getExtension(sanitizedFilename).toLowerCase();
            String baseName = FilenameUtils.getBaseName(sanitizedFilename);

            // 검증 로직
            if (!Arrays.asList(allowedExtensions).contains(extension)) {
                throw new FileExtensionNotAllowedException("등록 불가능한 확장자입니다.");
            }

            if (!isValidFilename(baseName)) {
                throw new FileUploadException("파일 이름이 유효하지 않습니다.");
            }

            if (file.getSize() > maxSize) {
                throw new FileSizeExceededException("파일 크기가 제한을 초과했습니다.");
            }

            if (containsNullByte(sanitizedFilename) || containsInvalidPath(sanitizedFilename)) {
                throw new FileUploadException("파일 이름이 잘못되었습니다.");
            }

            if (!isValidMimeType(file, extension)) {
                throw new FileUploadException("파일 콘텐츠 유형이 잘못되었습니다.");
            }

            if (hasPotentiallyDangerousContent(file, extension)) {
                throw new FileUploadException("파일에 잠재적으로 위험한 콘텐츠가 포함되어 있습니다.");
            }

            String randomFileName;
            Path destinationPath;
            do {
                randomFileName = generateRandomFileName(extension);
                destinationPath = getSafeFilePath(randomFileName);
            } while (Files.exists(destinationPath));

            // 업로드 경로가 존재하지 않으면 디렉토리 생성
            if (Files.notExists(destinationPath.getParent())) {
                Files.createDirectories(destinationPath.getParent());
            }

            Files.copy(file.getInputStream(), destinationPath);
            redirectAttributes.addFlashAttribute("message", "파일이 성공적으로 업로드되었습니다. 이름: " + randomFileName);
        } catch (IOException e) {
            throw new FileUploadException("파일 업로드에 실패했습니다.", e);
        }

        return "redirect:/";
    }

    @GetMapping("/download/{filename}")
    public ResponseEntity<byte[]> downloadFile(@PathVariable("filename") String filename) throws IOException {
        if (containsInvalidPath(filename) || containsNullByte(filename)) {
            return ResponseEntity.badRequest().body(null);
        }

        String extension = "." + FilenameUtils.getExtension(filename).toLowerCase();
        if (!Arrays.asList(downloadExtensions).contains(extension)) {
            return ResponseEntity.badRequest().body(null);
        }

        Path filePath = getSafeFilePath(filename);
        File file = filePath.toFile();
        if (!file.exists() || !file.isFile()) {
            return ResponseEntity.notFound().build();
        }

        byte[] fileContent = IOUtils.toByteArray(new FileInputStream(file));
        String mimeType = tika.detect(file);

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(mimeType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + sanitizeHeaderFilename(file.getName()) + "\"")
                .body(fileContent);
    }

    private List<String> listUploadedFiles() {
        File folder = new File(fileStorePath);
        File[] files = folder.listFiles();
        if (files != null) {
            return Arrays.stream(files)
                    .filter(File::isFile)
                    .map(File::getName)
                    .collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    private String generateRandomFileName(String extension) {
        return UUID.randomUUID().toString() + extension;
    }

    private boolean isValidMimeType(MultipartFile file, String extension) throws IOException {
        String mimeType = tika.detect(file.getInputStream());
        switch (extension) {
            case ".jpg":
            case ".jpeg":
                return mimeType.equals("image/jpeg");
            case ".png":
                return mimeType.equals("image/png");
            case ".gif":
                return mimeType.equals("image/gif");
            case ".pdf":
                return mimeType.equals("application/pdf");
            case ".xls":
            case ".xlsx":
                return mimeType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    || mimeType.equals("application/vnd.ms-excel");
            default:
                return false;
        }
    }

    private boolean containsNullByte(String filename) {
        return filename != null && filename.contains("\0");
    }

    private boolean containsInvalidPath(String filename) {
        Path filePath = Paths.get(fileStorePath).resolve(filename).normalize();
        return !filePath.startsWith(Paths.get(fileStorePath));
    }

    private boolean isValidFilename(String filename) {
        if (INVALID_FILENAMES.contains(filename.toUpperCase())) {
            return false;
        }
        return FILENAME_PATTERN.matcher(filename).matches();
    }

    private Path getSafeFilePath(String filename) {
        return Paths.get(fileStorePath).resolve(filename).normalize();
    }

    private String sanitizeFilename(String filename) {
        return filename.replaceAll("[^a-zA-Z0-9._\\- ]", "_");
    }

    private String sanitizeHeaderFilename(String filename) {
        return filename.replaceAll("[\\r\\n]", "_");
    }

    private boolean hasPotentiallyDangerousContent(MultipartFile file, String extension) throws IOException {
        try (InputStream inputStream = file.getInputStream();
             Scanner scanner = new Scanner(inputStream, StandardCharsets.UTF_8.name())) {
            String content = scanner.useDelimiter("\\A").next();

            // ImageTragick 방어
            if (extension.equals(".gif") && content.contains("shell_exec")) {
                return true;
            }

            // XXE 방어
            if ((extension.equals(".svg") || extension.equals(".xml")) && content.contains("DOCTYPE")) {
                return true;
            }

            // SVG to XSS 방어
            if (extension.equals(".svg") && (content.contains("<script") || content.contains("onload="))) {
                return true;
            }

            // SQL Injection 방어
            if (content.contains("'sleep(")) {
                return true;
            }

            // Pixel flood attack 방어
            if (extension.equals(".png") && file.getSize() > 1024 * 1024) { // 1MB 제한
                return true;
            }

            return false;
        }
    }
}


