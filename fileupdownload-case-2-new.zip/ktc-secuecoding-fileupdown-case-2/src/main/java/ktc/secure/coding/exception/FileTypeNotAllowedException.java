package ktc.secure.coding.exception;


public class FileTypeNotAllowedException extends FileUploadException {
    public FileTypeNotAllowedException(String message) {
        super(message);
    }
}
