package ktc.secure.coding.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public String handleMaxSizeException(RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("message", "File size exceeds the maximum limit!");
        return "redirect:/";
    }

    @ExceptionHandler(FileTypeNotAllowedException.class)
    public String handleFileTypeNotAllowedException(FileTypeNotAllowedException e, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("message", e.getMessage());
        return "redirect:/";
    }

    @ExceptionHandler(FileSizeExceededException.class)
    public String handleFileSizeExceededException(FileSizeExceededException e, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("message", e.getMessage());
        return "redirect:/";
    }

    @ExceptionHandler(FileExtensionNotAllowedException.class)
    public String handleFileExtensionNotAllowedException(FileExtensionNotAllowedException e, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("message", e.getMessage());
        return "redirect:/";
    }

    @ExceptionHandler(FileUploadException.class)
    public String handleFileUploadException(FileUploadException e, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("message", e.getMessage());
        return "redirect:/";
    }

    @ExceptionHandler(Exception.class)
    public String handleException(Exception e, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("message", "An error occurred: " + e.getMessage());
        return "redirect:/";
    }
}