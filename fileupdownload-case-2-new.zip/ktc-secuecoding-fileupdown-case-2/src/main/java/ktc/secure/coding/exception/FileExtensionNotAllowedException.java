package ktc.secure.coding.exception;

public class FileExtensionNotAllowedException extends FileUploadException {
    public FileExtensionNotAllowedException(String message) {
        super(message);
    }
}