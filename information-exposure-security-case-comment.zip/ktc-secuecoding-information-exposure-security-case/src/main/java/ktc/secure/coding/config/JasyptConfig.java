package ktc.secure.coding.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@Configuration
@EnableEncryptableProperties
public class JasyptConfig {

    // Spring 환경 설정 객체를 참조. 애플리케이션의 프로퍼티 값을 가져올 수 있음.
    private final Environment environment;

    // 로깅을 위한 Logger 인스턴스 생성. 이 클래스의 동작을 로그로 기록.
    private static final Logger logger = LoggerFactory.getLogger(JasyptConfig.class);

    // 암호를 캐싱하여 반복적으로 파일을 읽지 않도록 함. 
    // volatile 키워드를 사용하여 다중 스레드 환경에서도 안전하게 사용.
    private volatile String cachedPassword;

    // 생성자: Spring의 Environment 객체를 주입받아 환경 설정 값에 접근할 수 있도록 함.
    public JasyptConfig(Environment environment) {
        this.environment = environment;
    }

    // Jasypt의 StringEncryptor 빈(bean)을 생성. 애플리케이션에서 암호화를 사용할 수 있게 함.
    @Bean("jasyptStringEncryptor")
    public StringEncryptor stringEncryptor() {
        // 암호화에 사용할 비밀번호를 환경 설정에서 가져옴.
        String password = environment.getProperty("JASYPT_ENCRYPTOR_PASSWORD");
        // 비밀번호가 설정되지 않은 경우, 별도의 파일에서 비밀번호를 로드.
        if (password == null || password.isEmpty()) {
            String passwordFilePath = environment.getProperty("jasypt.encryptor.password-file");
            if (passwordFilePath != null) {
                password = loadPasswordFromFile(passwordFilePath);
            }
        }
        // 비밀번호가 여전히 설정되지 않은 경우 예외를 발생시켜 애플리케이션이 실행되지 않도록 함.
        if (password == null || password.isEmpty()) {
            throw new IllegalStateException("Encryption password cannot be null or empty");
        }

        // Jasypt의 암호화 객체를 생성하고 비밀번호와 알고리즘을 설정.
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(password);
        encryptor.setAlgorithm("PBEWithHMACSHA512AndAES_256");
        encryptor.setIvGenerator(new org.jasypt.iv.RandomIvGenerator()); // 초기화 벡터(IV) 생성기를 설정.
        return encryptor;
    }

    // 파일에서 비밀번호를 읽어오는 메서드.
    protected synchronized String loadPasswordFromFile(String filePath) {
        // 캐싱된 비밀번호가 있으면 다시 읽지 않고 그대로 반환.
        if (cachedPassword != null) {
            return cachedPassword;
        }
        try {
            // 파일에서 비밀번호를 읽고 캐시에 저장.
            cachedPassword = Files.readString(Paths.get(filePath));
            return cachedPassword;
        } catch (NoSuchFileException e) {
            // 비밀번호 파일을 찾지 못한 경우 로그를 기록하고 예외를 발생시킴.
            logger.error("Password file not found", e);
            throw new IllegalStateException("Password file not found", e);
        } catch (IOException e) {
            // 비밀번호 파일을 읽는 도중에 오류가 발생한 경우 로그를 기록하고 예외를 발생시킴.
            logger.error("Failed to load encryption password from file", e);
            throw new IllegalStateException("Failed to load encryption password from file", e);
        }
    }
}
