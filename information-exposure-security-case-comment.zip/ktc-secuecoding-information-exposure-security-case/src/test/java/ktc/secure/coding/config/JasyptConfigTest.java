package ktc.secure.coding.config;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.io.IOException;

import org.jasypt.encryption.StringEncryptor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;

public class JasyptConfigTest {

    @Mock
    private Environment environment;

    private JasyptConfig jasyptConfig;

    @TempDir
    Path tempDir;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        jasyptConfig = new JasyptConfig(environment);
    }

    @Test
    public void testStringEncryptor_withPasswordFile() throws Exception {
        Path passwordFile = tempDir.resolve("test-jasypt-password-file");
        Files.writeString(passwordFile, "filePassword", StandardOpenOption.CREATE);

        when(environment.getProperty("JASYPT_ENCRYPTOR_PASSWORD")).thenReturn(null);
        when(environment.getProperty("jasypt.encryptor.password-file")).thenReturn(passwordFile.toString());

        StringEncryptor encryptor = jasyptConfig.stringEncryptor();
        assertNotNull(encryptor);

        String encryptedText = encryptor.encrypt("testString");
        String decryptedText = encryptor.decrypt(encryptedText);

        assertEquals("testString", decryptedText);
    }

    @Test
    public void testLoadPasswordFromFile_fileNotFound() {
        when(environment.getProperty("JASYPT_ENCRYPTOR_PASSWORD")).thenReturn(null);
        when(environment.getProperty("jasypt.encryptor.password-file")).thenReturn("nonexistent.txt");

        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            jasyptConfig.stringEncryptor();
        });

        assertTrue(exception.getCause() instanceof NoSuchFileException);
        assertTrue(exception.getMessage().contains("Password file not found"));
    }
}
